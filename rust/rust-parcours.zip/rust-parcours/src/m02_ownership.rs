//! Module 2 — Ownership (propriété), move, clone, Drop
//! Lancer : cargo test m02

use std::cell::Cell;

/// Prend possession de `s` et la RENVOIE avec sa longueur.
/// (Vieille technique « je te rends ce que tu m'as donné » : au module 3 on verra mieux avec les emprunts.)
pub fn take_and_return_len(s: String) -> (String, usize) {
    todo!("à toi de jouer")
}

/// Met la chaîne en majuscules et ajoute un '!' à la fin.
/// Indice : `s.to_uppercase()` crée une nouvelle String ; `push` ajoute un char.
pub fn shout(s: String) -> String {
    todo!("à toi de jouer")
}

/// Consomme le Vec et concatène toutes les chaînes (boucle `for p in parts` = move de chaque élément).
pub fn concat_all(parts: Vec<String>) -> String {
    todo!("à toi de jouer")
}

/// Renvoie DEUX copies indépendantes de `s`.
/// Piège : l'ordre compte (on ne peut pas utiliser `s` après l'avoir déplacée).
pub fn duplicate(s: String) -> (String, String) {
    todo!("à toi de jouer")
}

/// Type `Copy` : copié bit à bit à chaque passage, jamais « déplacé ».
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct Meters(pub f64);

/// Additionne deux distances. Regarde le test : `a` reste utilisable après l'appel. Pourquoi ?
pub fn total_distance(a: Meters, b: Meters) -> Meters {
    todo!("à toi de jouer")
}

/// Équivalent d'un IDisposable / using : `drop` est appelé AUTOMATIQUEMENT en fin de portée.
/// (Ignore `'a` pour l'instant : ce sont les lifetimes, module 3.)
pub struct Tracker<'a> {
    pub counter: &'a Cell<u32>,
}

impl<'a> Drop for Tracker<'a> {
    /// Incrémente le compteur à chaque destruction.
    fn drop(&mut self) {
        todo!("à toi de jouer")
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn take_and_return() {
        let (s, n) = take_and_return_len(String::from("héllo"));
        assert_eq!(s, "héllo");
        assert_eq!(n, 6); // len() = octets UTF-8, pas caractères !
    }

    #[test]
    fn shout_works() {
        assert_eq!(shout("rust".to_string()), "RUST!");
    }

    #[test]
    fn concat_works() {
        let v = vec!["a".to_string(), "b".to_string(), "c".to_string()];
        assert_eq!(concat_all(v), "abc");
        assert_eq!(concat_all(vec![]), "");
    }

    #[test]
    fn duplicate_works() {
        let (a, mut b) = duplicate("x".to_string());
        b.push('y');
        assert_eq!(a, "x");
        assert_eq!(b, "xy");
    }

    #[test]
    fn copy_semantics() {
        let a = Meters(1.5);
        let b = Meters(2.0);
        let t = total_distance(a, b);
        // `a` est encore utilisable car Meters est Copy
        assert_eq!(total_distance(t, a), Meters(5.0));
    }

    #[test]
    fn drop_is_called_at_end_of_scope() {
        let counter = Cell::new(0);
        {
            let _t = Tracker { counter: &counter };
            assert_eq!(counter.get(), 0);
        }
        assert_eq!(counter.get(), 1);

        let t2 = Tracker { counter: &counter };
        drop(t2);
        assert_eq!(counter.get(), 2);
    }
}
