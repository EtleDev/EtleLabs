//! Module 11 — Projet final : un agrégat « Compte bancaire » en Event Sourcing / CQRS
//! Lancer : cargo test m11
//!
//! Tu retrouves tes réflexes DDD/CQRS, mais avec les outils de Rust :
//!   - Commande  = enum `AccountCommand`   (intention, peut être refusée)
//!   - Événement = enum `AccountEvent`     (fait, immuable, déjà arrivé)
//!   - Agrégat   = struct `Account`        (état reconstruit en rejouant les événements)
//!   - `decide`  : (état, commande) → Result<Vec<Événement>, ErreurDomaine>  — PURE, ne mute rien
//!   - `apply`   : (état, événement) → nouvel état                           — PURE, ne peut pas échouer
//!   - Pas d'exceptions : les erreurs métier sont des VALEURS (`Result`).
//!   - Les états illégaux sont écartés par le système de types + des règles dans `decide`.

use std::collections::HashMap;

#[derive(Debug, Clone, PartialEq)]
pub enum AccountCommand {
    Open { id: String, owner: String },
    Deposit { amount: u64 },
    Withdraw { amount: u64 },
    Close,
}

#[derive(Debug, Clone, PartialEq)]
pub enum AccountEvent {
    Opened { id: String, owner: String },
    Deposited { amount: u64 },
    Withdrawn { amount: u64 },
    Closed,
}

#[derive(Debug, Clone, PartialEq)]
pub enum DomainError {
    AlreadyOpened,
    NotOpened,
    AlreadyClosed,
    InvalidAmount,
    InsufficientFunds { balance: u64, requested: u64 },
    BalanceNotZero,
}

#[derive(Debug, Default, Clone, Copy, PartialEq, Eq)]
pub enum Status {
    #[default]
    NotOpened,
    Open,
    Closed,
}

#[derive(Debug, Default, Clone, PartialEq)]
pub struct Account {
    id: Option<String>,
    owner: Option<String>,
    balance: u64,
    status: Status,
}

impl Account {
    pub fn balance(&self) -> u64 {
        self.balance
    }

    pub fn status(&self) -> Status {
        self.status
    }

    pub fn owner(&self) -> Option<&str> {
        self.owner.as_deref()
    }

    /// Fourni : garde-fou réutilisable pour Deposit / Withdraw / Close.
    fn ensure_open(&self) -> Result<(), DomainError> {
        match self.status {
            Status::NotOpened => Err(DomainError::NotOpened),
            Status::Closed => Err(DomainError::AlreadyClosed),
            Status::Open => Ok(()),
        }
    }

    /// ÉTAPE 1 — Appliquer un événement à l'état (jamais d'erreur : un événement est un fait accompli).
    ///   Opened    → id/owner renseignés, status = Open
    ///   Deposited → balance += amount
    ///   Withdrawn → balance -= amount
    ///   Closed    → status = Closed
    pub fn apply(&mut self, event: &AccountEvent) {
        todo!("à toi de jouer")
    }

    /// ÉTAPE 2 — Reconstruire l'agrégat depuis son historique (event sourcing).
    /// Indice : `Account::default()` puis rejouer chaque événement avec `apply`.
    pub fn from_history(events: &[AccountEvent]) -> Account {
        todo!("à toi de jouer")
    }

    /// ÉTAPE 3 — Les règles métier. Renvoie les événements produits OU une erreur de domaine.
    ///   Open     : seulement si NotOpened (sinon AlreadyOpened)            → [Opened]
    ///   Deposit  : compte ouvert (ensure_open), amount > 0 (InvalidAmount) → [Deposited]
    ///   Withdraw : compte ouvert, amount > 0, amount <= balance
    ///              (sinon InsufficientFunds { balance, requested })         → [Withdrawn]
    ///   Close    : compte ouvert, balance == 0 (sinon BalanceNotZero)       → [Closed]
    /// Ordre des vérifications : statut d'abord, puis montant, puis solde.
    /// Note : `&self` — on ne modifie PAS l'état ici. Ce sont les événements qui le feront.
    pub fn decide(&self, cmd: AccountCommand) -> Result<Vec<AccountEvent>, DomainError> {
        todo!("à toi de jouer")
    }
}

// ---------------------------------------------------------------------------
// Infrastructure : un « repository » d'événements derrière un trait (port / adapter)
// ---------------------------------------------------------------------------

pub trait EventStore {
    fn load(&self, id: &str) -> Vec<AccountEvent>;
    fn append(&mut self, id: &str, events: Vec<AccountEvent>);
}

#[derive(Debug, Default)]
pub struct InMemoryStore {
    streams: HashMap<String, Vec<AccountEvent>>,
}

impl EventStore for InMemoryStore {
    /// Historique d'un flux (vide s'il n'existe pas). Indice : `get`, `cloned`, `unwrap_or_default`.
    fn load(&self, id: &str) -> Vec<AccountEvent> {
        todo!("à toi de jouer")
    }

    /// Ajoute des événements à la fin du flux. Indice : `entry(…).or_default().extend(…)`.
    fn append(&mut self, id: &str, events: Vec<AccountEvent>) {
        todo!("à toi de jouer")
    }
}

/// ÉTAPE 4 — Le « command handler » (côté écriture de CQRS) :
/// charger l'historique → reconstruire l'agrégat → décider → persister les nouveaux événements.
/// Générique sur le store (dispatch statique) : on peut tester avec InMemoryStore, brancher une vraie DB ensuite.
pub fn handle<S: EventStore>(store: &mut S, id: &str, cmd: AccountCommand) -> Result<(), DomainError> {
    todo!("à toi de jouer")
}

/// ÉTAPE 5 — Côté lecture (Q de CQRS) : une projection. Somme des soldes de plusieurs comptes.
/// Indice : `ids.iter().map(|id| …).sum()`.
pub fn total_balance<S: EventStore>(store: &S, ids: &[&str]) -> u64 {
    todo!("à toi de jouer")
}

#[cfg(test)]
mod tests {
    use super::*;

    fn open(store: &mut InMemoryStore, id: &str, owner: &str) {
        handle(
            store,
            id,
            AccountCommand::Open { id: id.to_string(), owner: owner.to_string() },
        )
        .unwrap();
    }

    #[test]
    fn apply_updates_state() {
        let mut acc = Account::default();
        acc.apply(&AccountEvent::Opened { id: "A".into(), owner: "Ada".into() });
        acc.apply(&AccountEvent::Deposited { amount: 100 });
        acc.apply(&AccountEvent::Withdrawn { amount: 30 });
        assert_eq!(acc.status(), Status::Open);
        assert_eq!(acc.balance(), 70);
        assert_eq!(acc.owner(), Some("Ada"));
        acc.apply(&AccountEvent::Closed);
        assert_eq!(acc.status(), Status::Closed);
    }

    #[test]
    fn rebuild_from_history() {
        let history = vec![
            AccountEvent::Opened { id: "A".into(), owner: "Ada".into() },
            AccountEvent::Deposited { amount: 500 },
            AccountEvent::Withdrawn { amount: 120 },
        ];
        let acc = Account::from_history(&history);
        assert_eq!(acc.balance(), 380);
        assert_eq!(Account::from_history(&[]).status(), Status::NotOpened);
    }

    #[test]
    fn decide_open_rules() {
        let acc = Account::default();
        let cmd = AccountCommand::Open { id: "A".into(), owner: "Ada".into() };
        let events = acc.decide(cmd.clone()).unwrap();
        assert_eq!(events, vec![AccountEvent::Opened { id: "A".into(), owner: "Ada".into() }]);

        let opened = Account::from_history(&events);
        assert_eq!(opened.decide(cmd), Err(DomainError::AlreadyOpened));
    }

    #[test]
    fn decide_requires_open_account() {
        let acc = Account::default();
        assert_eq!(acc.decide(AccountCommand::Deposit { amount: 10 }), Err(DomainError::NotOpened));
        assert_eq!(acc.decide(AccountCommand::Close), Err(DomainError::NotOpened));

        let closed = Account::from_history(&[
            AccountEvent::Opened { id: "A".into(), owner: "Ada".into() },
            AccountEvent::Closed,
        ]);
        assert_eq!(closed.decide(AccountCommand::Deposit { amount: 10 }), Err(DomainError::AlreadyClosed));
    }

    #[test]
    fn decide_amount_and_funds_rules() {
        let acc = Account::from_history(&[
            AccountEvent::Opened { id: "A".into(), owner: "Ada".into() },
            AccountEvent::Deposited { amount: 100 },
        ]);
        assert_eq!(acc.decide(AccountCommand::Deposit { amount: 0 }), Err(DomainError::InvalidAmount));
        assert_eq!(acc.decide(AccountCommand::Withdraw { amount: 0 }), Err(DomainError::InvalidAmount));
        assert_eq!(
            acc.decide(AccountCommand::Withdraw { amount: 150 }),
            Err(DomainError::InsufficientFunds { balance: 100, requested: 150 })
        );
        assert_eq!(
            acc.decide(AccountCommand::Withdraw { amount: 100 }),
            Ok(vec![AccountEvent::Withdrawn { amount: 100 }])
        );
        assert_eq!(acc.decide(AccountCommand::Close), Err(DomainError::BalanceNotZero));
    }

    #[test]
    fn decide_does_not_mutate() {
        let acc = Account::from_history(&[AccountEvent::Opened { id: "A".into(), owner: "Ada".into() }]);
        let before = acc.clone();
        let _ = acc.decide(AccountCommand::Deposit { amount: 50 });
        assert_eq!(acc, before);
    }

    #[test]
    fn store_roundtrip() {
        let mut store = InMemoryStore::default();
        assert!(store.load("A").is_empty());
        store.append("A", vec![AccountEvent::Deposited { amount: 1 }]);
        store.append("A", vec![AccountEvent::Deposited { amount: 2 }]);
        assert_eq!(store.load("A").len(), 2);
        assert!(store.load("B").is_empty());
    }

    #[test]
    fn full_scenario_through_handler() {
        let mut store = InMemoryStore::default();
        open(&mut store, "A", "Ada");
        handle(&mut store, "A", AccountCommand::Deposit { amount: 200 }).unwrap();
        handle(&mut store, "A", AccountCommand::Withdraw { amount: 50 }).unwrap();

        // une commande refusée ne persiste RIEN
        let err = handle(&mut store, "A", AccountCommand::Withdraw { amount: 1000 }).unwrap_err();
        assert_eq!(err, DomainError::InsufficientFunds { balance: 150, requested: 1000 });
        assert_eq!(store.load("A").len(), 3);

        handle(&mut store, "A", AccountCommand::Withdraw { amount: 150 }).unwrap();
        handle(&mut store, "A", AccountCommand::Close).unwrap();
        assert_eq!(Account::from_history(&store.load("A")).status(), Status::Closed);
    }

    #[test]
    fn projection_across_streams() {
        let mut store = InMemoryStore::default();
        open(&mut store, "A", "Ada");
        open(&mut store, "B", "Grace");
        handle(&mut store, "A", AccountCommand::Deposit { amount: 100 }).unwrap();
        handle(&mut store, "B", AccountCommand::Deposit { amount: 250 }).unwrap();
        assert_eq!(total_balance(&store, &["A", "B"]), 350);
        assert_eq!(total_balance(&store, &["A", "inconnu"]), 100);
        assert_eq!(total_balance(&store, &[]), 0);
    }
}
