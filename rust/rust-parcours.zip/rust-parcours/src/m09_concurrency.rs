//! Module 9 — Concurrence : threads, canaux, Arc<Mutex<T>>, Send/Sync
//! Lancer : cargo test m09
//!
//! Ici : uniquement la bibliothèque standard (pas de dépendance). L'async/await (tokio) est
//! présenté dans la leçon ; il demande une dépendance externe.

use std::sync::mpsc;
use std::sync::{Arc, Mutex};
use std::thread;

/// Somme un grand Vec en le découpant en `n_threads` morceaux, un thread par morceau.
/// Les données sont DÉPLACÉES (move) dans chaque thread : pas de data race possible.
/// Indices : `data.chunks(taille)`, `thread::spawn(move || …)`, `handle.join().unwrap()`.
/// Attention : `chunks(0)` panique → gérer data vide et n_threads == 0.
pub fn parallel_sum(data: Vec<i32>, n_threads: usize) -> i32 {
    todo!("à toi de jouer")
}

/// `n_threads` threads incrémentent chacun `increments` fois un compteur PARTAGÉ.
/// `Arc` = propriété partagée thread-safe (≈ Rc atomique) ; `Mutex` = exclusion mutuelle.
/// Différence clé avec C# : le Mutex POSSÈDE la donnée. Impossible d'y accéder sans verrouiller.
pub fn count_concurrently(n_threads: usize, increments: usize) -> usize {
    todo!("à toi de jouer")
}

/// Pipeline avec canaux (channels, style « message passing ») :
/// un thread « worker » reçoit les entiers, renvoie leur carré. L'ordre est conservé.
/// Indices : `mpsc::channel()`, `for x in rx` (s'arrête quand tous les `tx` sont droppés), `drop(tx)`.
pub fn square_in_worker(inputs: Vec<i32>) -> Vec<i32> {
    todo!("à toi de jouer")
}

/// Maximum d'une tranche en deux moitiés parallèles, SANS cloner les données :
/// `thread::scope` garantit que les threads finissent avant la fin du scope → ils peuvent EMPRUNTER.
/// Indices : `split_at(mid)`, `thread::scope(|s| { s.spawn(|| …) … })`, `iter().copied().max()`.
pub fn parallel_max(data: &[i32]) -> Option<i32> {
    todo!("à toi de jouer")
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn sum_in_parallel() {
        let data: Vec<i32> = (1..=1000).collect();
        assert_eq!(parallel_sum(data.clone(), 4), 500_500);
        assert_eq!(parallel_sum(data, 7), 500_500);
        assert_eq!(parallel_sum(vec![], 4), 0);
        assert_eq!(parallel_sum(vec![1, 2, 3], 0), 6);
        assert_eq!(parallel_sum(vec![1, 2, 3], 10), 6);
    }

    #[test]
    fn shared_counter() {
        assert_eq!(count_concurrently(8, 1000), 8000);
        assert_eq!(count_concurrently(0, 1000), 0);
    }

    #[test]
    fn worker_pipeline() {
        assert_eq!(square_in_worker(vec![1, 2, 3, 4]), vec![1, 4, 9, 16]);
        assert_eq!(square_in_worker(vec![]), Vec::<i32>::new());
    }

    #[test]
    fn scoped_max() {
        assert_eq!(parallel_max(&[3, 9, 2, 7]), Some(9));
        assert_eq!(parallel_max(&[5]), Some(5));
        assert_eq!(parallel_max(&[]), None);
        let big: Vec<i32> = (0..10_000).map(|x| (x * 37) % 1000).collect();
        assert_eq!(parallel_max(&big), big.iter().copied().max());
    }
}
