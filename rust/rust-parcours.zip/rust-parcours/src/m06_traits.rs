//! Module 6 — Traits et génériques
//! Lancer : cargo test m06

use std::ops::Add;

// ---------------------------------------------------------------------------
// Trait = interface. Ici une stratégie de remise (pattern Strategy).
// ---------------------------------------------------------------------------

pub trait Discount {
    /// Prix final (en centimes) après remise.
    fn apply(&self, price_cents: u64) -> u64;

    /// Méthode par défaut (comme une default interface method de C# 8).
    fn label(&self) -> String {
        "remise".to_string()
    }
}

pub struct NoDiscount;
pub struct Percentage(pub u8);
pub struct FixedAmount(pub u64);

impl Discount for NoDiscount {
    fn apply(&self, price_cents: u64) -> u64 {
        todo!("à toi de jouer")
    }
}

impl Discount for Percentage {
    /// Retire `pct`% du prix (pct plafonné à 100). Division entière (arrondi vers le bas).
    fn apply(&self, price_cents: u64) -> u64 {
        todo!("à toi de jouer")
    }

    /// Surcharge la méthode par défaut : "-10%" par exemple.
    fn label(&self) -> String {
        todo!("à toi de jouer")
    }
}

impl Discount for FixedAmount {
    /// Retire un montant fixe, sans jamais descendre sous 0 (indice : `saturating_sub`).
    fn apply(&self, price_cents: u64) -> u64 {
        todo!("à toi de jouer")
    }

    fn label(&self) -> String {
        todo!("à toi de jouer")
    }
}

/// DISPATCH DYNAMIQUE : une collection hétérogène via `Box<dyn Discount>` (vtable, comme une interface C#).
/// Applique les remises dans l'ordre, l'une après l'autre.
pub fn apply_all(discounts: &[Box<dyn Discount>], price: u64) -> u64 {
    todo!("à toi de jouer")
}

/// DISPATCH STATIQUE : générique → le compilateur génère une version par type (monomorphisation),
/// appel direct, inlinable, zéro coût. Différence avec .NET : les generics y sont réifiés à l'exécution, ici tout est résolu à la compilation.
pub fn apply_static<D: Discount>(d: &D, price: u64) -> u64 {
    todo!("à toi de jouer")
}

/// Libellés de toutes les remises, dans l'ordre.
pub fn labels(discounts: &[Box<dyn Discount>]) -> Vec<String> {
    todo!("à toi de jouer")
}

// ---------------------------------------------------------------------------
// Génériques avec contraintes (where T : IComparable en C#)
// ---------------------------------------------------------------------------

/// Plus grand élément d'une tranche, `None` si vide. Fonctionne pour i32, f64, char…
pub fn largest<T: PartialOrd + Copy>(items: &[T]) -> Option<T> {
    todo!("à toi de jouer")
}

#[derive(Debug, PartialEq)]
pub struct Pair<T> {
    pub a: T,
    pub b: T,
}

impl<T> Pair<T> {
    pub fn new(a: T, b: T) -> Self {
        todo!("à toi de jouer")
    }

    /// Échange a et b. Prend `self` par valeur : pas besoin de Clone.
    pub fn swap(self) -> Pair<T> {
        todo!("à toi de jouer")
    }
}

/// Méthodes disponibles SEULEMENT si T est comparable et copiable.
impl<T: PartialOrd + Copy> Pair<T> {
    pub fn largest(&self) -> T {
        todo!("à toi de jouer")
    }
}

// ---------------------------------------------------------------------------
// Traits de la bibliothèque standard : Add (opérateur +), From/Into
// ---------------------------------------------------------------------------

#[derive(Debug, Clone, Copy, PartialEq)]
pub struct Point {
    pub x: i32,
    pub y: i32,
}

impl Add for Point {
    type Output = Point;

    fn add(self, other: Point) -> Point {
        todo!("à toi de jouer")
    }
}

/// En implémentant `From<(i32, i32)>`, on obtient GRATUITEMENT `.into()` dans l'autre sens.
impl From<(i32, i32)> for Point {
    fn from(t: (i32, i32)) -> Self {
        todo!("à toi de jouer")
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn discounts() {
        assert_eq!(NoDiscount.apply(1000), 1000);
        assert_eq!(Percentage(10).apply(1000), 900);
        assert_eq!(Percentage(200).apply(1000), 0);
        assert_eq!(FixedAmount(300).apply(1000), 700);
        assert_eq!(FixedAmount(2000).apply(1000), 0);
    }

    #[test]
    fn labels_and_default_method() {
        assert_eq!(NoDiscount.label(), "remise");
        assert_eq!(Percentage(10).label(), "-10%");
        assert_eq!(FixedAmount(250).label(), "-250 cts");
    }

    #[test]
    fn dynamic_dispatch() {
        let ds: Vec<Box<dyn Discount>> = vec![
            Box::new(Percentage(10)),
            Box::new(FixedAmount(100)),
            Box::new(NoDiscount),
        ];
        assert_eq!(apply_all(&ds, 1000), 800);
        assert_eq!(labels(&ds), vec!["-10%", "-100 cts", "remise"]);
        assert_eq!(apply_all(&[], 500), 500);
    }

    #[test]
    fn static_dispatch() {
        assert_eq!(apply_static(&Percentage(50), 200), 100);
    }

    #[test]
    fn largest_generic() {
        assert_eq!(largest(&[3, 9, 2]), Some(9));
        assert_eq!(largest(&[1.5, -2.0]), Some(1.5));
        assert_eq!(largest(&['a', 'z', 'm']), Some('z'));
        assert_eq!(largest::<i32>(&[]), None);
    }

    #[test]
    fn pair_generic() {
        let p = Pair::new(1, 2).swap();
        assert_eq!(p, Pair { a: 2, b: 1 });
        assert_eq!(p.largest(), 2);
        // Pair<String> fonctionne pour new/swap (pas de contrainte) mais pas pour largest() (String n'est pas Copy)
        let s = Pair::new("a".to_string(), "b".to_string()).swap();
        assert_eq!(s.a, "b");
    }

    #[test]
    fn operators_and_conversions() {
        let p = Point { x: 1, y: 2 } + Point { x: 10, y: 20 };
        assert_eq!(p, Point { x: 11, y: 22 });
        let q: Point = (3, 4).into();
        assert_eq!(q, Point { x: 3, y: 4 });
        assert_eq!(Point::from((0, 0)), Point { x: 0, y: 0 });
    }
}
