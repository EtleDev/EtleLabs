//! Module 3 — Emprunts (&, &mut) et lifetimes
//! Lancer : cargo test m03

/// Renvoie la plus longue des deux chaînes (la première en cas d'égalité).
/// Pourquoi `<'a>` ici, alors que `first_word` n'en a pas besoin ? Lis la leçon.
pub fn longest<'a>(a: &'a str, b: &'a str) -> &'a str {
    todo!("à toi de jouer")
}

/// Premier mot d'une phrase ("" si vide). Retourne une *tranche* de l'entrée : zéro copie.
pub fn first_word(s: &str) -> &str {
    todo!("à toi de jouer")
}

/// Ajoute tous les éléments de `extra` à la fin de `target`.
/// Note les types : `&mut Vec<i32>` (on modifie) et `&[i32]` (on lit — accepte Vec, tableau, tranche).
pub fn append_all(target: &mut Vec<i32>, extra: &[i32]) {
    todo!("à toi de jouer")
}

/// Met chaque nom en minuscules et sans espaces autour, EN PLACE.
pub fn normalize(names: &mut [String]) {
    todo!("à toi de jouer")
}

/// Remplace le contenu de `slot` par `new` et renvoie l'ancienne valeur.
/// On ne peut pas « déplacer hors » d'une référence &mut… sauf avec `std::mem::replace`.
pub fn replace_name(slot: &mut String, new: String) -> String {
    todo!("à toi de jouer")
}

/// Une pile d'entiers. Le champ `items` est privé : invariant protégé (cf. DDD).
#[derive(Debug, Default)]
pub struct Stack {
    items: Vec<i32>,
}

impl Stack {
    pub fn new() -> Self {
        todo!("à toi de jouer")
    }

    /// `&mut self` : modifie la pile.
    pub fn push(&mut self, v: i32) {
        todo!("à toi de jouer")
    }

    /// Retire et renvoie le sommet.
    pub fn pop(&mut self) -> Option<i32> {
        todo!("à toi de jouer")
    }

    /// `&self` : lecture seule. Renvoie une RÉFÉRENCE au sommet, sans le retirer.
    pub fn peek(&self) -> Option<&i32> {
        todo!("à toi de jouer")
    }

    pub fn len(&self) -> usize {
        todo!("à toi de jouer")
    }

    /// `self` (sans &) : CONSOMME la pile et rend le Vec interne. La pile n'existe plus après l'appel.
    pub fn into_vec(self) -> Vec<i32> {
        todo!("à toi de jouer")
    }
}

/// Un mini-lexer qui EMPRUNTE son entrée (un type avec lifetime).
pub struct Parser<'a> {
    input: &'a str,
}

impl<'a> Parser<'a> {
    pub fn new(input: &'a str) -> Self {
        todo!("à toi de jouer")
    }

    /// Prochain « mot » (séparé par des espaces), ou None à la fin.
    /// Le token renvoyé vit aussi longtemps que l'ENTRÉE ('a), pas que le `&mut self`.
    pub fn next_token(&mut self) -> Option<&'a str> {
        todo!("à toi de jouer")
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn longest_works() {
        assert_eq!(longest("abc", "de"), "abc");
        assert_eq!(longest("ab", "cde"), "cde");
        assert_eq!(longest("ab", "cd"), "ab");
    }

    #[test]
    fn first_word_works() {
        assert_eq!(first_word("  hello world"), "hello");
        assert_eq!(first_word(""), "");
    }

    #[test]
    fn append_all_works() {
        let mut v = vec![1, 2];
        append_all(&mut v, &[3, 4]);
        assert_eq!(v, vec![1, 2, 3, 4]);
    }

    #[test]
    fn normalize_works() {
        let mut names = vec!["  Ada ".to_string(), "GRACE".to_string()];
        normalize(&mut names);
        assert_eq!(names, vec!["ada".to_string(), "grace".to_string()]);
    }

    #[test]
    fn replace_works() {
        let mut s = "old".to_string();
        let previous = replace_name(&mut s, "new".to_string());
        assert_eq!(previous, "old");
        assert_eq!(s, "new");
    }

    #[test]
    fn stack_works() {
        let mut s = Stack::new();
        assert_eq!(s.pop(), None);
        s.push(1);
        s.push(2);
        assert_eq!(s.len(), 2);
        assert_eq!(s.peek(), Some(&2));
        assert_eq!(s.pop(), Some(2));
        s.push(3);
        assert_eq!(s.into_vec(), vec![1, 3]);
    }

    #[test]
    fn parser_works() {
        let text = String::from("  let x  = 5 ");
        let mut p = Parser::new(&text);
        let a = p.next_token().unwrap();
        let b = p.next_token().unwrap();
        // a et b restent valides alors que p est ré-emprunté : ils dépendent de `text`, pas de `p`.
        assert_eq!(a, "let");
        assert_eq!(b, "x");
        assert_eq!(p.next_token(), Some("="));
        assert_eq!(p.next_token(), Some("5"));
        assert_eq!(p.next_token(), None);
        assert_eq!(p.next_token(), None);
    }
}
