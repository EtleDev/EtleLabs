#![allow(unused, dead_code)]
//! Parcours Rust — exercices.
//! Lance `cargo test m01` (puis m02, m03…) pour travailler module par module.

pub mod m01_bases;
pub mod m02_ownership;
pub mod m03_borrowing;
pub mod m04_types;
pub mod m05_errors;
pub mod m06_traits;
pub mod m07_iterators;
pub mod m08_collections;
pub mod m09_concurrency;
pub mod m11_capstone;
