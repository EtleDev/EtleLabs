# Module 0 — Introduction : Rust vu depuis .NET

## L'idée centrale
Rust vise les performances de C/C++ **sans ramasse-miettes** et **sans comportements indéfinis**.
Le prix : le compilateur te demande de **prouver** que ton code gère bien la mémoire et la concurrence.
Tu passes du temps à discuter avec le compilateur, et en échange les bugs de mémoire,
les data races et les `NullReferenceException` n'existent pas à l'exécution.

Ce qui n'existe PAS en Rust (et que tu devras désapprendre) :
- **L'héritage de classes** → composition + traits.
- **Le null** → `Option<T>`.
- **Les exceptions** → `Result<T, E>` (des valeurs de retour).
- **Le GC** → ownership + `Drop` (RAII déterministe).
- **La réflexion / l'injection par conteneur** → génériques + traits, résolus à la compilation.
- **La mutabilité par défaut** → tout est immuable sauf si on écrit `mut`.

## Table de correspondance .NET → Rust

| .NET | Rust |
|---|---|
| `dotnet` CLI | `cargo` |
| `.csproj` / `.sln` | `Cargo.toml` / *workspace* |
| NuGet | crates.io (les paquets = *crates*) |
| assembly | *crate* |
| namespace | `mod` (module) |
| `interface` | `trait` |
| classe abstraite / héritage | composition + traits (méthodes par défaut) |
| `class` / `record` | `struct` (+ `#[derive(...)]`) |
| `enum` (entiers nommés) | `enum` **à données** (type somme / union discriminée) |
| `switch` expression | `match` (exhaustif) |
| `null`, `T?` | `Option<T>` |
| `try/catch/throw` | `Result<T, E>`, opérateur `?`, `panic!` (bug irrécupérable) |
| `IDisposable` / `using` | `Drop` (automatique en fin de portée) |
| `string` | `String` (possédée) et `&str` (vue empruntée) |
| `Span<T>` / `ReadOnlySpan<T>` | `&mut [T]` / `&[T]` (tranches) |
| LINQ | itérateurs (`map`, `filter`, `collect`…) |
| `Func<>`, lambdas | closures (`Fn`, `FnMut`, `FnOnce`) |
| `lock` / `Monitor` | `Mutex<T>` qui **contient** la donnée |
| `Task` / `async` | `Future` / `async` + un *runtime* externe (tokio) |
| xUnit `[Fact]` | `#[test]` |
| `Debug.Assert` / `Assert.Equal` | `assert!` / `assert_eq!` |
| `ToString()` | trait `Display` |
| `IEquatable`, `IComparable` | `PartialEq`/`Eq`, `PartialOrd`/`Ord` (dérivables) |
| operator overloading | traits `Add`, `Mul`, … |
| `unsafe` | `unsafe` (mais minuscule et **localisé**) |

## Installation
```bash
# https://rustup.rs
rustup update stable
rustc --version && cargo --version
rustup component add clippy rustfmt   # linter + formateur
```
Éditeur : VS Code + **rust-analyzer** (ou RustRover).

## Les 6 commandes cargo à connaître
```bash
cargo new mon_projet      # crée un projet
cargo build               # compile (cargo build --release pour l'optimisé)
cargo run                 # compile + exécute
cargo test                # lance les tests
cargo clippy              # linter (indispensable pour apprendre l'idiomatique)
cargo fmt                 # formate le code
```

## Comment utiliser ce parcours
1. Lis `lessons/NN-….md`.
2. Ouvre `src/mNN_….rs` : chaque fonction contient `todo!()` et des tests.
3. `cargo test mNN` → les tests échouent → tu implémentes → ils passent.
4. Les dossiers `fix/` contiennent des programmes qui **ne compilent pas** : le but est de lire l'erreur
   du compilateur et de corriger (c'est LA compétence Rust).
5. `solutions/` : à consulter **après** avoir essayé.

Chaque leçon se termine par un encadré **🔍 Réflexe revue de code IA** : ce que les assistants IA font
souvent de travers dans ce domaine. C'est ton objectif final : garder l'esprit critique.

> Astuce : lis les messages du compilateur **en entier**. Ceux de Rust sont les meilleurs de l'industrie :
> ils expliquent le problème, montrent la ligne, et proposent souvent le correctif.
