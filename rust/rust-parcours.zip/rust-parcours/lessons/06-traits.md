# Module 6 — Traits et génériques

## Trait = interface (mais plus puissant)
```rust
trait Discount {
    fn apply(&self, price: u64) -> u64;
    fn label(&self) -> String { "remise".into() }     // méthode par défaut
}
struct Percentage(u8);
impl Discount for Percentage { fn apply(&self, p: u64) -> u64 { /* … */ } }
```
Différences avec les interfaces C# :
- On peut implémenter un trait **pour un type existant** (même de la std) : `impl MyTrait for i32` — tant que le trait OU le type est à toi (*règle de l'orphelin*).
- Pas d'héritage de classes : on **compose** des comportements (traits) sur des données (structs).
- Un trait peut avoir des **types associés** (`type Item;`) et des constantes.

## Deux façons de les utiliser

### 1. Générique = dispatch **statique** (monomorphisation)
```rust
fn total<D: Discount>(d: &D, p: u64) -> u64 { d.apply(p) }
fn total(d: &impl Discount, p: u64) -> u64    // sucre syntaxique équivalent
```
Le compilateur génère **une version par type concret**. Appel direct, inlinable, coût zéro. Contrepartie : taille du binaire, temps de compilation, pas de collection hétérogène.

### 2. Trait object `dyn` = dispatch **dynamique**
```rust
let ds: Vec<Box<dyn Discount>> = vec![Box::new(Percentage(10)), Box::new(FixedAmount(5))];
```
Appel via une *vtable* (comme une interface C#). Permet les collections hétérogènes et le polymorphisme à l'exécution. Contraintes : le trait doit être « *object-safe* ».

**Quand choisir quoi ?** Par défaut **générique / enum**. `dyn` quand tu as besoin d'un ensemble ouvert de types décidés à l'exécution (plugins, stratégies injectées).

Alternative souvent meilleure pour un **ensemble fermé** : un `enum` + `match` (exhaustif, pas d'allocation).

## Génériques avec contraintes
```rust
fn largest<T: PartialOrd + Copy>(items: &[T]) -> Option<T>
fn complex<T, U>(t: T, u: U) where T: Clone + Debug, U: Into<String> { … }
```
Équivalent de `where T : IComparable<T>`, mais les génériques Rust sont **monomorphisés** (pas réifiés à l'exécution comme en .NET).

## Traits de la std à connaître (et à *dériver*)
| Trait | Rôle | C# |
|---|---|---|
| `Debug` / `Display` | formatage debug / humain | `ToString()` |
| `Clone` / `Copy` | duplication | `ICloneable` / struct |
| `PartialEq` / `Eq` / `Hash` | égalité / clé de dictionnaire | `Equals`/`GetHashCode` |
| `PartialOrd` / `Ord` | ordre | `IComparable` |
| `Default` | valeur par défaut | `default(T)` / ctor sans args |
| `From` / `Into` / `TryFrom` | conversions | opérateurs implicites/explicites |
| `Add`, `Mul`, `Index`… | opérateurs | operator overloading |
| `Iterator` | itération | `IEnumerable` |
| `Drop` | destruction | `IDisposable` |
| `Send` / `Sync` | sûr entre threads | *(rien)* |

`impl From<A> for B` donne **gratuitement** `a.into()`. C'est l'idiome de conversion (et le carburant de `?`).

## `impl Trait` en retour
```rust
fn evens() -> impl Iterator<Item = u32> { (0..).step_by(2) }
```
« Je renvoie *un* type qui implémente ce trait, sans le nommer. » Pas d'allocation, contrairement à `Box<dyn Iterator>`.

## 🔍 Réflexe revue de code IA
- `Box<dyn Trait>` partout « par habitude objet » alors qu'un générique ou un `enum` suffisait (allocation + indirection inutiles).
- Traits « Manager/Service/Repository » ultra-découpés avec une seule implémentation : du Java/C# porté tel quel (sur-abstraction).
- Génériques avec 6 contraintes illisibles → simplifier ou introduire un trait intermédiaire.
- `impl Trait for T where T: …` (impl blanket) mal compris : peut créer des conflits de cohérence.
- Simulation d'héritage via `Deref` (anti-pattern connu).

## Exercices
`src/m06_traits.rs` → `cargo test m06`
