# Module 1 — Les bases

## Variables : immuables par défaut
```rust
let x = 5;          // immuable (comme `readonly` / `val`)
// x = 6;           // ERREUR de compilation
let mut y = 5;      // mutable : on doit le DIRE
y += 1;
```
**Shadowing** : on peut redéclarer un nom. C'est un *nouveau* binding (type éventuellement différent), pas une mutation.
```rust
let s = "  42 ";
let s = s.trim();             // &str
let s: i32 = s.parse().unwrap(); // maintenant un i32
```

## Types scalaires
`i8 i16 i32 i64 i128 isize` · `u8 … usize` · `f32 f64` · `bool` · `char` (4 octets, un *point de code Unicode*).
Pas de conversion implicite entre entiers : `let a: i64 = x as i64;` ou `i64::from(x)` (sans perte) / `i32::try_from(big)` (vérifié).

**Débordement arithmétique** : en *debug* → `panic` ; en *release* → *wrap-around silencieux* ! Soit explicite :
`checked_add` (Option), `wrapping_add`, `saturating_add`, `overflowing_add`.

## Composés
```rust
let t: (i32, f64, &str) = (1, 2.0, "a");  let (a, b, c) = t;  t.0
let arr: [i32; 3] = [1, 2, 3];            // taille fixe, sur la pile
let v: Vec<i32> = vec![1, 2, 3];          // taille dynamique, sur le tas (≈ List<T>)
```

## Tout est (presque) une expression
```rust
let label = if n > 0 { "pos" } else { "neg" };   // if est une expression
let r = loop { break 42; };                      // loop aussi
fn f(x: i32) -> i32 { x + 1 }                    // pas de `;` = valeur de retour
```
**Attention au `;`** : `x + 1;` renvoie `()` (« unit »), pas un entier.

## Contrôle de flux
```rust
for i in 0..5 {}       // 0,1,2,3,4        for i in 0..=5 {} // inclusif
for x in &v {}         // emprunte chaque élément (module 3)
while cond {}          loop { if done { break; } }
match n { 0 => "zéro", 1..=9 => "petit", _ => "grand" }   // exhaustif
```

## Fonctions
```rust
fn add(a: i32, b: i32) -> i32 { a + b }
```
Les signatures sont **toujours** typées (pas d'inférence entre fonctions) ; l'inférence agit dans les corps.

## `&str` vs `String` (aperçu)
`&str` = vue sur du texte (littéraux, tranches). `String` = texte possédé et extensible. La suite au module 2-3.

## 🔍 Réflexe revue de code IA
- `as` pour convertir : `x as u8` **tronque silencieusement**. Préfère `u8::try_from(x)`.
- `v[i]` panique si hors limites ; `v.get(i)` renvoie un `Option`.
- `&s[0..3]` sur un `String` **panique** si la coupe tombe au milieu d'un caractère UTF-8.
- `.len()` d'une `String` = **octets**, pas caractères.
- `.unwrap()` partout : voir module 5.

## Exercices
`src/m01_bases.rs` → `cargo test m01`
