# Module 5 — Erreurs : Option, Result, `?`

## Deux catégories, deux mécanismes
| Situation | Rust | Équivalent C# |
|---|---|---|
| Erreur **attendue** (entrée invalide, fichier absent, règle métier violée) | `Result<T, E>` | exception « métier » / `OneOf` / `Result<T>` |
| **Bug** (invariant brisé, index hors limites) | `panic!` | exception non rattrapée |

Il n'y a pas de `try/catch` pour le flux normal : les erreurs sont des **valeurs** dans la signature, impossibles à ignorer.

```rust
enum Result<T, E> { Ok(T), Err(E) }
fn parse_age(s: &str) -> Result<u8, AgeError>
```
`#[must_use]` : ignorer un `Result` produit un avertissement.

## L'opérateur `?` (propagation)
```rust
fn read_config(path: &str) -> Result<Config, ConfigError> {
    let text = std::fs::read_to_string(path)?;   // si Err → retourne l'erreur (convertie) immédiatement
    let port = text.trim().parse::<u16>()?;
    Ok(Config { port })
}
```
`?` fait : `match r { Ok(v) => v, Err(e) => return Err(e.into()) }`. Le `.into()` utilise `From` : c'est ce qui convertit l'erreur de la bibliothèque en **ton** type d'erreur.

## Définir ses erreurs
```rust
#[derive(Debug)]
pub enum ConfigError { Missing(String), Invalid(ParseIntError) }
impl std::fmt::Display for ConfigError { /* message humain */ }
impl std::error::Error for ConfigError {}
impl From<ParseIntError> for ConfigError { fn from(e: ParseIntError) -> Self { Self::Invalid(e) } }
```
En pratique on utilise des crates pour éviter le boilerplate :
- **`thiserror`** : dérive `Display`/`Error`/`From` — pour les **bibliothèques** et les erreurs de domaine précises.
- **`anyhow`** : `anyhow::Result<T>` = « n'importe quelle erreur + contexte » — pour les **applications** (main, scripts).

`Box<dyn Error>` : erreur type-effacée ; pratique en prototype, mais perd la possibilité de `match` sur la cause.

## Combinateurs d'Option / Result
```rust
opt.map(|x| x + 1)             opt.and_then(|x| f(x))      // f renvoie un Option
opt.unwrap_or(0)               opt.unwrap_or_else(|| compute())
opt.ok_or(Err)                 opt.ok_or_else(|| Err)      // Option → Result
res.map_err(|e| MyErr::from(e))                            // convertir l'erreur
res.ok()                                                   // Result → Option (jette l'erreur)
```

## unwrap / expect : à manier avec précaution
- `unwrap()` = « panique si None/Err ». OK dans les **tests**, les exemples, ou quand c'est *prouvé* impossible.
- `expect("raison")` : pareil mais documente **pourquoi** c'est censé être impossible.
- Dans du code applicatif/de domaine : propage avec `?`.

## Domaine DDD
Un agrégat retourne `Result<Events, DomainError>` : l'erreur de domaine est un **enum du langage ubiquitaire** (`InsufficientFunds { balance, requested }`), pas une chaîne de caractères. Tu le verras dans le projet final.

## 🔍 Réflexe revue de code IA
- `.unwrap()` / `.expect()` dans du code de production : chaque occurrence = une panique potentielle. À justifier.
- `.map_err(|e| e.to_string())?` : détruit la cause d'origine (plus de `match`, plus de `source()`).
- `Result<T, String>` : erreurs en chaînes = non testables proprement. Préfère un enum.
- `let _ = fallible();` : erreur **ignorée silencieusement**.
- `Box<dyn Error>` dans l'API publique d'une lib.
- `panic!` pour une erreur de validation d'entrée utilisateur.

## Exercices
`src/m05_errors.rs` → `cargo test m05`
