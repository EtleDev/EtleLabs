# Module 3 — Emprunts (borrowing) et lifetimes

## Deux sortes de références
```rust
fn len(s: &String) -> usize { s.len() }        // &T   : emprunt PARTAGÉ, lecture seule
fn push_bang(s: &mut String) { s.push('!'); }  // &mut : emprunt EXCLUSIF, lecture/écriture
```
`let n = len(&s);` — `s` reste propriétaire, on ne fait que « prêter ».

## La règle d'or (aliasing XOR mutation)
À tout instant, pour une donnée, tu as **soit** :
- autant de `&T` que tu veux,
- **soit** un seul `&mut T`,
mais **jamais les deux en même temps**.

C'est ce qui rend impossibles : l'invalidation d'itérateur (`InvalidOperationException: Collection was modified`), les data races, les références pendantes. Détectés **à la compilation**.

```rust
let mut v = vec![1, 2, 3];
let first = &v[0];       // emprunt partagé
v.push(4);               // ERREUR : emprunt mutable pendant que `first` est vivant
println!("{}", first);
```

## Les références ne peuvent pas survivre à leur donnée
```rust
fn bad() -> &String { let s = String::new(); &s }   // ERREUR : `s` meurt à la fin de la fonction
```
Solution : renvoyer la valeur possédée (`String`).

## Tranches (slices) : `&str` et `&[T]`
- `&str` : vue sur du texte UTF-8. Un `&String` se convertit automatiquement en `&str`.
- `&[T]` : vue sur une suite contiguë. Un `&Vec<T>` ou `&[T; N]` s'y convertit.

**Règle d'API** : en paramètre, préfère `&str` à `&String` et `&[T]` à `&Vec<T>`. Plus général, aucun coût.

## Lifetimes : « combien de temps vit cette référence ? »
Le plus souvent le compilateur les **déduit** (*élision*) :
```rust
fn first_word(s: &str) -> &str      // le résultat emprunte `s` — déduit
```
Quand il y a ambiguïté (deux entrées), tu dois **annoter** :
```rust
fn longest<'a>(a: &'a str, b: &'a str) -> &'a str
```
Lis : « le résultat ne vit pas plus longtemps que le **plus court** des deux arguments ».
L'annotation ne *change* rien à la durée de vie ; elle **décrit** une relation pour le compilateur.

Une struct qui contient une référence a aussi un lifetime :
```rust
struct Parser<'a> { input: &'a str }
```
Elle ne peut pas survivre à la chaîne qu'elle emprunte.

`'static` = vit pendant tout le programme (ex. les littéraux `"abc"`). Un `&'static str` n'est pas « magique » : c'est juste une référence vers des données qui ne disparaissent jamais.

## Les 3 modes de `self` dans une méthode
| Signature | Sens | Équivalent C# |
|---|---|---|
| `fn f(&self)` | lecture | méthode normale (ou `readonly`) |
| `fn f(&mut self)` | modification | méthode qui mute l'état |
| `fn f(self)` | **consomme** l'objet | méthode qui « termine » un builder / transforme en autre chose |

## 🔍 Réflexe revue de code IA
- `&Vec<T>`, `&String`, `&Box<T>` en paramètre → clippy (`ptr_arg`) râle ; préfère `&[T]`, `&str`, `&T`.
- Lifetimes partout (`struct Order<'a> { customer: &'a str }`) dans un **modèle de domaine** : presque toujours un mauvais choix. Un agrégat DDD **possède** ses données (`String`). Les lifetimes sont pour les *vues temporaires* (parseurs, itérateurs).
- `.clone()` pour échapper à une erreur d'emprunt : demande-toi si on peut simplement **réordonner** le code ou réduire la portée de l'emprunt.
- `Rc<RefCell<…>>` pour contourner un emprunt : voir module 8.

## Exercices
`src/m03_borrowing.rs` → `cargo test m03`
Puis `fix/m03_01_aliasing.rs`, `fix/m03_02_dangling.rs`.
