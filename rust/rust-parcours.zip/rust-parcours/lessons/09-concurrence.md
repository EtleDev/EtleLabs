# Module 9 — Concurrence : « fearless concurrency »

## L'idée
Les règles d'ownership/borrowing qui évitent les bugs mémoire évitent **aussi les data races** : le compilateur refuse de compiler un programme qui partage de la mémoire mutable entre threads sans synchronisation.

## Threads
```rust
let handle = std::thread::spawn(move || { /* travail */ 42 });
let result = handle.join().unwrap();      // attend + récupère la valeur (Err si le thread a paniqué)
```
`spawn` exige une closure `'static` : elle ne peut pas emprunter de variable locale → on **déplace** (`move`) les données dedans. Pour *emprunter* quand même : `std::thread::scope` (les threads sont garantis terminés avant la fin du scope).

## Send et Sync : les traits « marqueurs »
- `T: Send` → `T` peut être **déplacé** vers un autre thread.
- `T: Sync` → `&T` peut être **partagé** entre threads.
Dérivés automatiquement. `Rc<T>` n'est **ni Send ni Sync** (compteur non atomique) → `thread::spawn` avec un `Rc` ne compile pas. Il faut `Arc<T>`. Voir `fix/m09_01_rc_thread.rs`.

## Partager de l'état : Arc<Mutex<T>>
```rust
let counter = Arc::new(Mutex::new(0));
let c = Arc::clone(&counter);
thread::spawn(move || { *c.lock().unwrap() += 1; });
```
**Différence majeure avec C#** : le `Mutex<T>` **contient** la donnée. Impossible de la toucher sans verrouiller (en C#, `lock(obj)` et la donnée sont deux choses séparées : on peut oublier le verrou). Le verrou se libère automatiquement quand le *guard* est détruit (RAII).
- `RwLock<T>` : plusieurs lecteurs OU un écrivain.
- **Poisoning** : si un thread panique en tenant le verrou, le Mutex est « empoisonné » (`lock()` renvoie `Err`). D'où les `.unwrap()` courants.
- Attention aux **deadlocks** : Rust protège des data races, **pas** des deadlocks.

## Passage de messages : canaux
```rust
let (tx, rx) = std::sync::mpsc::channel();
let tx2 = tx.clone();                       // mpsc = multiple producers, single consumer
thread::spawn(move || tx.send(1).unwrap());
for msg in rx { /* s'arrête quand tous les tx sont détruits */ }
```
Mantra : *« Ne communique pas en partageant la mémoire ; partage la mémoire en communiquant. »*

## Async / await (aperçu — demande la crate `tokio`)
```rust
#[tokio::main]
async fn main() {
    let body = fetch("https://…").await;
}
```
Différences avec C# `Task` :
- Un `Future` Rust est **paresseux** : rien ne s'exécute tant qu'on ne l'`await` pas ou qu'on ne le `spawn` pas (un `Task` C# démarre immédiatement).
- **Pas de runtime intégré** : on choisit (tokio, async-std, smol). Tokio est le standard de fait.
- Le compilateur transforme chaque `async fn` en machine à états, sans allocation obligatoire.
- Pas de `SynchronizationContext`; le problème « fonction colorée » (async contamine l'appelant) existe comme en C#.

Pièges classiques :
1. **Bloquer le runtime** : appeler du code bloquant (`std::thread::sleep`, I/O synchrone, calcul lourd) dans une tâche async → utiliser `tokio::task::spawn_blocking` / `tokio::time::sleep`.
2. **Garder un `std::sync::MutexGuard` à travers un `.await`** → le future n'est plus `Send` (erreur) ou risque de deadlock. Utiliser `tokio::sync::Mutex` ou réduire la portée du verrou.
3. Oublier d'`await` : `let f = foo();` ne fait **rien** (avertissement `unused must_use`).

## 🔍 Réflexe revue de code IA
- `Arc<Mutex<AppState>>` géant partagé partout : contention + risque de deadlock. Préférer des canaux, des verrous à grain fin, ou des acteurs.
- `lock().unwrap()` répété sans réfléchir au *poisoning*.
- Verrou tenu pendant une opération longue ou un `.await`.
- `thread::spawn` sans jamais `join` (erreurs/panics perdus).
- `Mutex<i32>` pour un simple compteur → `AtomicUsize` (sans verrou).
- `async fn` qui appelle du bloquant ; `block_on` imbriqué dans un contexte async (deadlock).
- `unsafe impl Send/Sync` : très suspect, exige une justification écrite.

## Exercices
`src/m09_concurrency.rs` → `cargo test m09`
Puis `fix/m09_01_rc_thread.rs`.
