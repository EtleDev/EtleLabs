# Module 10 — Modules, crates, outillage, `unsafe`, macros (leçon de lecture)

## Organisation du code
```
mon_projet/
  Cargo.toml
  src/
    main.rs     (ou lib.rs)
    domain/
      mod.rs    (ou domain.rs)
      account.rs
```
```rust
mod domain;                      // déclare le module (cherche domain.rs ou domain/mod.rs)
use domain::account::Account;    // importe
pub(crate) fn interne() {}       // visible dans la crate seulement (≈ `internal` C#)
pub fn publique() {}             // visible partout
```
Visibilité : privé (défaut) < `pub(super)` < `pub(crate)` < `pub`. Équivalence : `pub(crate)` ≈ `internal`.

- **crate** = unité de compilation (binaire `main.rs` ou librairie `lib.rs`) ≈ assembly.
- **workspace** = plusieurs crates dans un repo (≈ solution `.sln`) : `[workspace] members = ["core", "api"]`.
- **features** = compilation conditionnelle (`[features]`), ≈ `#if` structurés.
- **edition** (2021, 2024) : versions du langage, mélangeables entre crates.

## Dépendances et crates incontournables
```toml
[dependencies]
serde = { version = "1", features = ["derive"] }   # (dé)sérialisation (≈ System.Text.Json)
serde_json = "1"
thiserror = "1"      # erreurs de lib
anyhow = "1"         # erreurs d'appli
tokio = { version = "1", features = ["full"] }     # runtime async
tracing = "0.1"      # logs structurés (≈ ILogger)
clap = "4"           # arguments CLI
axum = "0.7"         # web (autres : actix-web)
sqlx = "0.7"         # SQL asynchrone vérifié à la compilation
```
`Cargo.lock` : commité pour les binaires/applis (builds reproductibles).

## Outillage
```bash
cargo clippy -- -D warnings    # linter strict (200+ règles pédagogiques)
cargo fmt                      # format standard unique (plus de débat de style)
cargo doc --open               # documentation générée (commentaires `///` + exemples testés !)
cargo test                     # unitaires (dans le fichier, `#[cfg(test)] mod tests`), d'intégration (dossier `tests/`), et doctests
cargo audit                    # vulnérabilités des dépendances
cargo expand                   # voir le code généré par les macros
```
Les exemples dans `///` sont **exécutés comme des tests** (doctests).

## Tests
```rust
#[cfg(test)]
mod tests {
    use super::*;
    #[test] fn it_works() { assert_eq!(add(1, 2), 3); }
    #[test] #[should_panic(expected = "boom")] fn panics() { … }
    #[test] fn with_result() -> Result<(), String> { … Ok(()) }
}
```
TDD : très naturel (tu viens de le faire depuis le module 1 !). Les tests unitaires vivent **à côté** du code et peuvent tester les éléments privés.

## `unsafe`
Cinq super-pouvoirs : déréférencer un pointeur brut, appeler une fonction `unsafe`, accéder à un `static mut`, implémenter un trait `unsafe` (`Send`/`Sync`), accéder aux champs d'une `union`.
- `unsafe` **ne désactive pas** le borrow checker ; il te laisse promettre au compilateur « je garantis l'invariant ».
- On l'isole dans de petits blocs avec un commentaire `// SAFETY: …` qui justifie pourquoi c'est correct.
- Usage légitime : FFI (appeler du C), structures de données bas niveau, optimisations mesurées.
- Dans du code applicatif généré par IA, un `unsafe` est **presque toujours** un signal d'alarme.

## Macros
```rust
println!("{}", x);  vec![1, 2];  assert_eq!(a, b);  format!(..);  matches!(..);  todo!();
```
Le `!` signale une **macro** (génération de code à la compilation, *hygiénique*), pas une fonction.
- `macro_rules!` : macros déclaratives (par motifs).
- **Macros procédurales** : `#[derive(Serialize)]`, `#[tokio::main]`, `#[test]` : du code Rust qui produit du code Rust.
Pour lire du code qui en abuse : `cargo expand`.

## 🔍 Réflexe revue de code IA
- Un module `utils.rs` / `helpers.rs` fourre-tout, des fichiers de 2000 lignes.
- Tout `pub` « pour que ça compile » → casse l'encapsulation (choisir `pub(crate)` ou privé).
- Dépendances ajoutées à la légère : vérifie la maintenance (crates.io, dernière version), la licence, et `cargo audit`.
- `unwrap()` dans `main` sans `anyhow`, absence de `Result` dans `main`.
- Code non formaté / warnings clippy ignorés : exige `cargo fmt --check` et `cargo clippy -D warnings` en CI.
- `#[allow(...)]` posé pour réduire au silence un avertissement légitime.
