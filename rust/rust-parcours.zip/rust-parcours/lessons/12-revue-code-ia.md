# Module 12 — Lire et critiquer du Rust généré par l'IA

Objectif final : être capable de relire un diff produit par un assistant et dire **« non, pas comme ça »** en sachant pourquoi.

## Checklist de revue (12 questions)
1. **Panics cachées** : `unwrap`, `expect`, `v[i]`, `&s[a..b]`, `/` par zéro, `as` qui tronque, overflow en release ?
2. **Clones** : chaque `.clone()` est-il justifié ? Un emprunt ou un réordonnancement suffisait-il ?
3. **Signatures** : `&str`/`&[T]` plutôt que `&String`/`&Vec<T>` ? Propriété prise (`String`) sans nécessité ?
4. **Erreurs** : types d'erreur précis (enum + `thiserror`) ? `?` plutôt que `unwrap` ? Erreurs avalées (`let _ =`, `.ok()`) ?
5. **Encapsulation** : champs `pub` ? Invariants protégés par des constructeurs (`new`/`parse`) ?
6. **Modélisation** : `enum` pour les états/variantes, pas des `bool`/`Option`/chaînes magiques ?
7. **Pointeurs partagés** : `Rc<RefCell>` / `Arc<Mutex>` — y a-t-il un design avec propriété claire ?
8. **Dyn vs générique** : `Box<dyn Trait>` justifié (ensemble ouvert) ou habitude objet ?
9. **Concurrence/async** : bloquant dans l'async ? verrou tenu à travers `.await` ? `join` oublié ?
10. **`unsafe`** : y en a-t-il ? `// SAFETY:` convaincant ? Existe-t-il une alternative sûre ?
11. **Dépendances** : nécessaires, maintenues, auditées ? Versions fixées ?
12. **Outillage** : `cargo fmt`, `cargo clippy -D warnings`, tests présents ET qui testent vraiment (pas que le *happy path*) ?

> Garde en tête : **« ça compile » ≠ « c'est bon »**. Le compilateur garantit la sûreté mémoire et l'absence de data race ;
> il ne garantit ni la logique métier, ni l'absence de panic, ni la performance, ni la bonne architecture.

---

## Exercices : revue de 8 extraits

Pour chaque extrait, note : **(a)** ce qui ne va pas, **(b)** le risque réel, **(c)** comment tu le corrigerais.
Les corrigés détaillés sont dans `solutions/12-corrige-revue.md` — **essaie d'abord** (ou fais-en une revue orale avec Claude Code).

### Extrait 1 — Service de commandes
```rust
pub fn total(prices: &Vec<String>) -> u32 {
    let mut sum = 0;
    for p in prices.clone() {
        sum += p.parse::<u32>().unwrap();
    }
    sum
}
```

### Extrait 2 — Modèle de domaine
```rust
pub struct Order<'a> {
    pub id: &'a str,
    pub customer: &'a str,
    pub status: String,          // "pending" | "paid" | "shipped"
    pub tracking: Option<String>,
    pub total: f64,
}
```

### Extrait 3 — Graphe d'objets
```rust
struct Customer { orders: Vec<Rc<RefCell<Order>>> }
struct Order    { customer: Rc<RefCell<Customer>>, lines: Vec<Rc<RefCell<Line>>> }
```

### Extrait 4 — Gestion d'erreurs
```rust
fn load(path: &str) -> Result<Config, String> {
    let text = std::fs::read_to_string(path).map_err(|e| e.to_string())?;
    let cfg: Config = serde_json::from_str(&text).map_err(|e| e.to_string())?;
    let _ = validate(&cfg);
    Ok(cfg)
}
```

### Extrait 5 — État partagé
```rust
type Shared = Arc<Mutex<AppState>>;

async fn handle(state: Shared, req: Request) -> Response {
    let mut s = state.lock().unwrap();
    let user = db.fetch_user(req.user_id).await;     // appel réseau
    s.last_seen.insert(req.user_id, now());
    Response::ok(user)
}
```

### Extrait 6 — Polymorphisme
```rust
pub trait ShippingStrategy { fn cost(&self, w: f64) -> f64; }
pub struct Standard; pub struct Express;
// … 2 implémentations, jamais d'autres, connues à la compilation …

pub fn price(strategy: Box<dyn ShippingStrategy>, w: f64) -> f64 { strategy.cost(w) }
```

### Extrait 7 — Conversions et indexation
```rust
fn age_bucket(age: i64) -> u8 { (age / 10) as u8 }
fn initials(name: &str) -> String { format!("{}{}", &name[0..1], &name[name.len() - 1..]) }
```

### Extrait 8 — `unsafe`
```rust
fn get_unchecked(v: &Vec<i32>, i: usize) -> i32 {
    unsafe { *v.as_ptr().add(i) }
}
```

---

## Mise en situation finale
Demande à Claude Code de te générer, **sans que tu lui dictes la solution**, une petite API de gestion de tâches en Rust
(par exemple « un CRUD de TODO avec axum et stockage en mémoire »). Puis fais une revue avec la checklist ci-dessus,
**avant** de lire ses explications. Compare ensuite avec lui : qu'as-tu repéré ? qu'as-tu raté ?
