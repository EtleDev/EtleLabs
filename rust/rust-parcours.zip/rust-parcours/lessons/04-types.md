# Module 4 — Structs, enums, pattern matching

## Struct = ton « record/class » de données
```rust
#[derive(Debug, Clone, PartialEq)]
pub struct Customer { name: String, age: u8 }     // champs privés par défaut !

impl Customer {
    pub fn new(name: &str, age: u8) -> Self { Self { name: name.to_string(), age } }
    pub fn name(&self) -> &str { &self.name }      // accesseur
}
```
- Pas de constructeurs : par convention une fonction associée `new` (ou `parse`, `try_new`…).
- **Visibilité par module** : privé = visible dans le module courant (et ses enfants). Parfait pour protéger des invariants.
- `#[derive(...)]` génère `Debug`, `Clone`, `Copy`, `PartialEq`, `Eq`, `Hash`, `PartialOrd`, `Ord`, `Default`.
  Ex. `#[derive(PartialEq)]` ≈ égalité structurelle d'un `record` C#.

## Enum : le type somme (ce que C# n'a pas vraiment)
```rust
enum Shape {
    Circle { radius: f64 },
    Rectangle { width: f64, height: f64 },
}
```
Chaque variante peut porter **des données différentes**. C'est un « type union discriminée ».
Équivalent C# : une hiérarchie de classes `Shape` / `Circle : Shape` + `switch` sur le type — mais ici fermé, compact, **exhaustif**.

## match : exhaustif
```rust
fn area(s: &Shape) -> f64 {
    match s {
        Shape::Circle { radius } => PI * radius * radius,
        Shape::Rectangle { width, height } => width * height,
    }
}
```
Si tu ajoutes `Triangle`, **tous** les `match` concernés cessent de compiler. Fini les `default: throw new NotImplementedException()`.

Patterns utiles :
```rust
match code { 200..=299 => .., 404 | 410 => .., c if c >= 500 => .., _ => .. }   // intervalles, |, garde
if let Some(x) = opt { .. }                      // un seul cas
let Some(x) = opt else { return; };              // let-else
matches!(state, State::A | State::B { .. })     // booléen
```

## Rendre les états invalides irreprésentables
```rust
enum Order {
    Draft,
    Placed { items: Vec<Item> },
    Shipped { tracking: String },   // `tracking` n'existe QUE si expédiée : pas de Option<String> flottant
}
```
En C# on ferait `class Order { string? Tracking; OrderStatus Status; }` et on espérerait que `Tracking != null` ⇔ `Status == Shipped`. Ici le compilateur l'impose.

## Newtype & « parse, don't validate »
```rust
pub struct Email(String);                       // champ privé
impl Email { pub fn parse(s: &str) -> Option<Email> { /* valide */ } }
```
Une fois construit, un `Email` est valide **par construction** → plus besoin de revalider partout. Ça fait des *Value Objects* DDD très légers et sans coût à l'exécution.

## Option<T> : plus de null
```rust
enum Option<T> { None, Some(T) }
```
Le compilateur t'oblige à traiter `None`. Un `Option<String>` n'est pas un `String` : pas de `NullReferenceException`.

## 🔍 Réflexe revue de code IA
- Une struct avec **tous ses champs `pub`** : encapsulation inexistante, invariants non protégés. En DDD, c'est un red flag.
- Des `bool` / `Option` en cascade (`is_shipped: bool, tracking: Option<String>`) là où un **enum** modéliserait proprement.
- Un `match` avec `_ => {}` fourre-tout qui masque de futures variantes : préfère lister les variantes.
- Chaînes magiques (`"pending"`) au lieu d'un `enum`.

## Exercices
`src/m04_types.rs` → `cargo test m04`
