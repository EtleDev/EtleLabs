# Module 2 — Ownership : LE concept de Rust

## Les 3 règles
1. Chaque valeur a **un seul propriétaire** (une variable).
2. Il ne peut y avoir qu'**un propriétaire à la fois**.
3. Quand le propriétaire sort de la portée, la valeur est **détruite** (`Drop`) — immédiatement, de façon déterministe.

C'est du RAII : comme `using`/`IDisposable`, mais **automatique pour toutes les ressources** (mémoire, fichiers, sockets, verrous).

## Move (déplacement)
```rust
let a = String::from("salut");
let b = a;                 // `a` est DÉPLACÉE dans `b`
// println!("{}", a);      // ERREUR : borrow of moved value: `a`
```
Pas de copie, pas de double libération possible. C'est la différence fondamentale avec C# où `b = a` copie une *référence* (les deux vivent, le GC ramasse plus tard).

Un `move` a aussi lieu **quand on passe une valeur à une fonction** ou qu'on itère avec `for x in vec` :
```rust
fn consume(s: String) {}
let s = String::from("x");
consume(s);        // s est déplacée DANS la fonction
// s n'existe plus ici
```

## Copy vs Clone
- **`Copy`** : types simples dont la copie bit-à-bit est triviale (`i32`, `f64`, `bool`, `char`, tuples/structs de `Copy`). Copiés automatiquement, jamais déplacés.
- **`Clone`** : copie **explicite** potentiellement coûteuse : `let b = a.clone();`. Tu *vois* le coût dans le code.
- Une struct qui contient un `String` ou un `Vec` n'est **pas** `Copy`.

```rust
#[derive(Clone, Copy)] struct Meters(f64);   // OK : f64 est Copy
```

## Drop : l'équivalent de IDisposable
```rust
impl Drop for Connection { fn drop(&mut self) { /* fermer */ } }
{
    let c = Connection::open();
} // ← drop appelé ICI, automatiquement, même en cas de `?` ou de panic
```
On ne peut pas oublier de libérer, ni libérer deux fois.
Les valeurs sont détruites dans l'ordre **inverse** de leur déclaration. `std::mem::drop(x)` détruit plus tôt.

## Pourquoi c'est génial
- Pas de GC → pas de pauses, mémoire prévisible.
- Pas de *use-after-free*, de *double-free*, de fuites « classiques ».
- La propriété est aussi la base de la **sécurité threads** (module 9).

## Fonctions : « donner » est lourd → on emprunte (module 3)
Dans les exercices du module 2 tu verras l'ancienne technique « je te rends ce que tu m'as donné ». C'est pénible : c'est exactement pour ça que les **références** existent.

## 🔍 Réflexe revue de code IA
- **`.clone()` à tout va** pour « faire taire » le borrow checker. Chaque `.clone()` doit avoir une raison. Cherche : clone dans une boucle, clone d'un gros `Vec`, clone avant un appel qui n'avait besoin que d'une référence.
- `#[derive(Clone)]` sur absolument tous les types : parfois voulu, souvent un réflexe.
- Paramètres `String` / `Vec<T>` (par valeur) alors que `&str` / `&[T]` suffiraient → force l'appelant à cloner.

## Exercices
`src/m02_ownership.rs` → `cargo test m02`
Puis dans `fix/` : `m02_01_move.rs`, `m02_02_loop.rs` (fais-les compiler).
