# Module 7 — Closures et itérateurs

## Closures
```rust
let add = |a, b| a + b;                  // types inférés
let n = 10;
let add_n = move |x| x + n;              // `move` : capture PAR VALEUR (prend possession)
```
Trois traits, selon ce que la closure fait de ses captures :
| Trait | La closure… | Appelable |
|---|---|---|
| `Fn` | ne fait que **lire** ses captures | plusieurs fois, en parallèle |
| `FnMut` | **modifie** ses captures | plusieurs fois, un appel à la fois |
| `FnOnce` | **consomme** ses captures (move out) | une seule fois |

Hiérarchie : tout `Fn` est un `FnMut`, tout `FnMut` est un `FnOnce`. En paramètre, demande le **plus faible nécessaire** (`FnOnce` > `FnMut` > `Fn` en permissivité pour l'appelant).

Renvoyer une closure : `fn f() -> impl Fn(i32) -> i32` (ou `Box<dyn Fn(i32) -> i32>` si les types diffèrent).

## Itérateurs = LINQ, mais compilés à zéro coût
```rust
let total: i32 = v.iter()
    .filter(|x| **x % 2 != 0)     // Where
    .map(|x| x * x)               // Select
    .sum();                       // Sum
```
| LINQ | Rust |
|---|---|
| `Where` | `filter` |
| `Select` | `map` |
| `SelectMany` | `flat_map` |
| `First`/`FirstOrDefault` | `next()` / `find(..)` |
| `Any` / `All` | `any(..)` / `all(..)` |
| `Count` / `Sum` / `Max` / `Min` | `count()` / `sum()` / `max()` / `min()` |
| `ToList()` / `ToDictionary` | `collect::<Vec<_>>()` / `collect::<HashMap<_,_>>()` |
| `OrderBy` | `sort_by_key` (sur un Vec, **en place**) |
| `GroupBy` | pas natif (itertools) → `HashMap` + `entry` |
| `Zip`, `Skip`, `Take` | `zip`, `skip`, `take` |
| `Aggregate` | `fold` |

**Paresseux** : rien n'est calculé tant qu'un *consommateur* (`collect`, `sum`, `for`…) n'est pas appelé. Le compilateur fusionne la chaîne en une seule boucle.

### Les trois façons d'itérer
```rust
for x in &v      // iter()       → &T      (emprunt)
for x in &mut v  // iter_mut()   → &mut T  (modification en place)
for x in v       // into_iter()  → T       (CONSOMME v)
```
Le dernier cas est celui du piège « use of moved value » après la boucle.

### `collect` est polymorphe
```rust
let v: Vec<i32> = it.collect();
let s: String = chars.collect();
let r: Result<Vec<i32>, _> = strs.iter().map(|s| s.parse::<i32>()).collect(); // tout-ou-rien
```
Le type cible (annotation ou « turbofish » `::<Vec<_>>`) détermine le résultat.

## Implémenter un itérateur
Un seul besoin : `fn next(&mut self) -> Option<Self::Item>` → tu obtiens `map/filter/take/zip/sum…` gratuitement.

## 🔍 Réflexe revue de code IA
- Boucle `for` + `push` dans un `Vec` mutable là où une chaîne `map/filter/collect` est plus claire (et l'inverse : chaînes de 12 combinateurs illisibles).
- `.collect::<Vec<_>>()` intermédiaire inutile, puis nouvelle itération : on peut souvent **enchaîner** directement.
- `.iter().cloned().collect()` / `.to_vec()` pour dupliquer quand on pouvait emprunter.
- `.clone()` dans un `map` (`.map(|x| x.clone())`) → `.cloned()` ; si c'est du `Copy` → `.copied()`.
- `.unwrap()` dans une closure de `map` au lieu de propager via `collect::<Result<_,_>>()`.
- `.len() == 0` plutôt que `.is_empty()`.

## Exercices
`src/m07_iterators.rs` → `cargo test m07`
