# Module 11 — Projet final : Event Sourcing / CQRS en Rust

Tu vas écrire, avec tes réflexes DDD, un **agrégat « Compte bancaire »** :

```
        Command ──▶ decide(&self, cmd) ──▶ Result<Vec<Event>, DomainError>
                          ▲                          │
                          │                          ▼
  EventStore.load ─▶ from_history(events)      EventStore.append
                          ▲                          │
                          └────────── apply(&mut self, event) ◀─ (rejeu)
```

## Pourquoi cet exercice est un bon résumé de Rust
| Concept Rust | Où |
|---|---|
| `enum` à données | `AccountCommand`, `AccountEvent`, `DomainError` (le langage ubiquitaire) |
| `match` exhaustif | `apply` et `decide` : ajouter une commande/événement casse la compilation tant qu'on n'a pas tout traité |
| `Result` + `?` | `decide` et `handle` : erreurs de domaine = valeurs, pas d'exceptions |
| Ownership | `decide(&self)` ne mute pas ; `apply(&mut self, &Event)` est le seul à muter |
| Traits | `EventStore` = port (comme une interface de repository) |
| Génériques | `handle<S: EventStore>` : dispatch statique, testable avec `InMemoryStore` |
| Itérateurs | `total_balance` = projection (côté **Query** de CQRS) |
| Encapsulation | champs de `Account` privés, accès par méthodes → invariants protégés |

## Les 5 étapes (ordre conseillé)
1. `Account::apply`
2. `Account::from_history`
3. `Account::decide`  ← le cœur métier
4. `InMemoryStore::load` / `append`, puis `handle`
5. `total_balance` (projection)

`cargo test m11` — les tests décrivent le comportement attendu (lis-les d'abord : ce sont tes spécifications).

## Questions de réflexion (à discuter avec Claude Code)
1. Pourquoi `apply` ne retourne-t-il pas de `Result` ? Où sont les vérifications ?
2. Que se passerait-il en C# avec un `switch` oubliant une commande ? Et ici ?
3. `decide(&self, …)` prend `self` en lecture seule. Quel bug ce choix rend-il impossible ?
4. Dans `handle`, pourquoi une commande refusée ne laisse-t-elle **aucune trace** dans le store ?
5. Comment ajouterais-tu la **concurrence optimiste** (numéro de version du flux) ? Quel type d'erreur ajouterais-tu ?

## Extensions (bonus)
- Ajoute un `Transfer { to, amount }` : que doit renvoyer `decide` ? (indice : deux agrégats → *saga*/*process manager*.)
- Remplace `u64` par un newtype `Money` validé (module 4) et un type `AccountId`.
- `trait EventStore` asynchrone (nécessite `tokio` + `async_trait` ou les `async fn` dans les traits stables).
- Persiste le store dans un fichier JSON avec `serde`.
- Écris un `AccountSummary` (read model) mis à jour par un `Projector` qui consomme les événements.
