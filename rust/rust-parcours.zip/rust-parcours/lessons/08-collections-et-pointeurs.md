# Module 8 — Collections et pointeurs intelligents

## Collections courantes
| Rust | .NET | Remarques |
|---|---|---|
| `Vec<T>` | `List<T>` | contigu, redimensionnable |
| `[T; N]`, `&[T]` | tableau, `Span<T>` | taille fixe / vue |
| `HashMap<K, V>` | `Dictionary<K,V>` | hash **résistant aux attaques** (SipHash), donc un peu plus lent par défaut |
| `BTreeMap<K, V>` | `SortedDictionary` | trié, ordre déterministe |
| `HashSet<T>`, `BTreeSet<T>` | `HashSet`, `SortedSet` | |
| `VecDeque<T>` | `LinkedList`/file | file à deux bouts |
| `String` / `&str` | `string` / `ReadOnlySpan<char>` | UTF-8 (pas UTF-16) |

**API Entry** : évite le double lookup `if !contains { insert }; get`.
```rust
*counts.entry(word).or_insert(0) += 1;
groups.entry(key).or_default().push(item);
```
**Indexation** : `map["clé"]` panique si absente ; `map.get("clé")` renvoie un `Option<&V>`.

## Pointeurs intelligents : qui possède quoi ?
| Type | Propriété | Threads ? | Usage |
|---|---|---|---|
| `Box<T>` | unique, sur le **tas** | oui (si T: Send) | types récursifs, `dyn Trait` possédé, gros objets |
| `Rc<T>` | **partagée**, comptage de références | **non** | graphes, données partagées en mono-thread |
| `Arc<T>` | partagée, comptage **atomique** | oui | idem entre threads |
| `RefCell<T>` | mutabilité **intérieure** vérifiée à l'EXÉCUTION | non | muter à travers un `&` |
| `Mutex<T>` / `RwLock<T>` | mutabilité intérieure **thread-safe** | oui | état partagé entre threads |
| `Cell<T>` | mutabilité intérieure pour `Copy`, sans verrou | non | compteurs simples |

### Box : types récursifs
```rust
enum List { Cons(i32, Box<List>), Nil }     // sans Box : taille infinie → erreur de compilation
```

### Rc<RefCell<T>> : propriété partagée + mutation
```rust
let shared = Rc::new(RefCell::new(vec![]));
let a = Rc::clone(&shared);                 // +1 sur le compteur (pas une copie des données)
a.borrow_mut().push(1);                     // vérif d'emprunt à l'EXÉCUTION → panic si violé !
```
`RefCell` **déplace** la règle « un seul `&mut` » du compilateur vers le runtime : une violation = `panic`. C'est un outil légitime mais à utiliser consciemment.

**Cycles** : deux `Rc` qui se référencent **fuient** (compteur jamais à 0). Casse le cycle avec `Weak<T>` (ex. parent → enfant en `Rc`, enfant → parent en `Weak`).

## L'état d'esprit « idiomatique »
Avant d'écrire `Rc<RefCell<…>>`, demande-toi :
1. Un **arbre de propriété** (le parent possède ses enfants) suffit-il ?
2. Peut-on utiliser des **identifiants/indices** (`Vec<Node>` + `NodeId`) plutôt que des pointeurs ?
3. Peut-on **passer** les données (messages, paramètres) plutôt que les **partager** ?

## 🔍 Réflexe revue de code IA
- **`Rc<RefCell<T>>` / `Arc<Mutex<T>>` pour tout** : le design « graphe d'objets » du C#/Java transposé. Signe qu'on a contourné l'ownership au lieu de le modéliser.
- `RefCell` : `borrow_mut()` deux fois dans une même portée → **panic à l'exécution** que le compilateur ne voit pas.
- `Rc` de `Rc` sans `Weak` → fuite mémoire.
- `HashMap` indexé par `map[&key]` (panique) là où `get` est attendu.
- `Box<T>` inutile (`Box<i32>`, `Box<String>`) ou `Vec<Box<T>>` quand `Vec<T>` suffit.
- `Arc` utilisé « au cas où » dans un programme mono-thread (coût atomique inutile).

## Exercices
`src/m08_collections.rs` → `cargo test m08`
