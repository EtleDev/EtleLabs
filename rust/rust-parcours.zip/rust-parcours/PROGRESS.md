# Suivi de progression

| # | Module | Leçon | Exercices | Fix | Revue IA | Statut |
|---|---|---|---|---|---|---|
| 0 | Introduction (.NET → Rust) | `00` | — | — | — | ☐ |
| 1 | Bases | `01` | `m01` | — | ☐ | ☐ |
| 2 | Ownership | `02` | `m02` | `m02_01`, `m02_02` | ☐ | ☐ |
| 3 | Emprunts & lifetimes | `03` | `m03` | `m03_01`, `m03_02` | ☐ | ☐ |
| 4 | Structs, enums, match | `04` | `m04` | — | ☐ | ☐ |
| 5 | Erreurs (Option/Result) | `05` | `m05` | — | ☐ | ☐ |
| 6 | Traits & génériques | `06` | `m06` | — | ☐ | ☐ |
| 7 | Closures & itérateurs | `07` | `m07` | — | ☐ | ☐ |
| 8 | Collections & pointeurs intelligents | `08` | `m08` | — | ☐ | ☐ |
| 9 | Concurrence | `09` | `m09` | `m09_01` | ☐ | ☐ |
| 10 | Modules, outillage, unsafe, macros | `10` | (lecture) | — | ☐ | ☐ |
| 11 | Projet final (ES/CQRS) | `11` | `m11` | — | ☐ | ☐ |
| 12 | Lire du Rust généré par l'IA | `12` | revue de 8 extraits | — | ☐ | ☐ |

## Notes / points à revoir
-
