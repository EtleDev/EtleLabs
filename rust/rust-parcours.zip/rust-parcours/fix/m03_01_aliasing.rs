// OBJECTIF : faire COMPILER en gardant l'intention (afficher le premier score, ajouter 40).
// Il y a (au moins) DEUX corrections valables. Trouve-les et explique la différence.
//
// Lancer :  rustc --edition 2021 fix/m03_01_aliasing.rs --out-dir target/fix && target/fix/m03_01_aliasing

fn main() {
    let mut scores = vec![10, 20, 30];

    let first = &scores[0];
    scores.push(40);

    println!("premier = {}", first);
}
