// OBJECTIF : faire COMPILER, sans cloner le Vec.
// Question à te poser : que fait `for n in names` à `names` ?
//
// Lancer :  rustc --edition 2021 fix/m02_02_loop.rs --out-dir target/fix && target/fix/m02_02_loop

fn main() {
    let names = vec![String::from("Ada"), String::from("Grace")];

    for n in names {
        println!("{}", n);
    }

    println!("{} noms traités", names.len());
}
