// OBJECTIF : faire COMPILER ce programme, SANS utiliser .clone().
// Tu ne peux modifier que la signature de `print_len` et l'appel dans `main`.
//
// Lancer :  rustc --edition 2021 fix/m02_01_move.rs --out-dir target/fix && target/fix/m02_01_move
//           (Windows : target\fix\m02_01_move.exe)
//
// Lis le message du compilateur EN ENTIER avant de toucher au code.

fn print_len(s: String) {
    println!("longueur = {}", s.len());
}

fn main() {
    let name = String::from("Rust");
    print_len(name);
    println!("{} est toujours utilisable", name);
}
