// OBJECTIF : faire COMPILER. Pourquoi le compilateur refuse-t-il de renvoyer `&s` ?
// Indice : qui possède la String à la fin de `make_greeting` ?
//
// Lancer :  rustc --edition 2021 fix/m03_02_dangling.rs --out-dir target/fix && target/fix/m03_02_dangling

fn make_greeting() -> &str {
    let s = String::from("Bonjour");
    &s
}

fn main() {
    println!("{}", make_greeting());
}
