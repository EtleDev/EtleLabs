// OBJECTIF : faire COMPILER. Lis l'erreur : elle mentionne `Send`.
// Pourquoi `Rc<T>` n'est-il pas autorisé entre threads ? Que faut-il utiliser ?
//
// Lancer :  rustc --edition 2021 fix/m09_01_rc_thread.rs --out-dir target/fix && target/fix/m09_01_rc_thread

use std::rc::Rc;
use std::thread;

fn main() {
    let data = Rc::new(vec![1, 2, 3]);
    let d = Rc::clone(&data);

    let handle = thread::spawn(move || {
        println!("dans le thread : {:?}", d);
    });

    handle.join().unwrap();
    println!("dans main : {:?}", data);
}
