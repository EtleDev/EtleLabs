# Parcours Rust pour architecte .NET

Parcours de 13 modules (0 → 12), ~25-35 h, conçu pour un développeur .NET/DDD/CQRS/TDD expérimenté
dont l'objectif est de **comprendre et critiquer** du code Rust (notamment généré par IA).

## Démarrage rapide
```bash
# 1. Installer Rust : https://rustup.rs
rustup component add clippy rustfmt

# 2. Vérifier que le projet compile (les tests échouent, c'est normal : `todo!()`)
cargo test --no-run

# 3. Travailler module par module
cargo test m01          # puis m02, m03 ... m09, m11
```

## Avec Claude Code (recommandé)
```bash
cd rust-parcours
claude
```
Puis dis simplement : **« Commençons »** (ou « Reprenons au module 3 »).
Le fichier `CLAUDE.md` le configure en tuteur : il pose des questions, donne des indices par paliers et ne livre pas les solutions.

## Contenu
- `lessons/` — 13 leçons, chacune avec un encadré « 🔍 Réflexe revue de code IA ».
- `src/` — exercices à trous (`todo!()`) validés par des tests (TDD : rouge → vert).
- `fix/` — programmes qui ne compilent pas : apprends à **lire le compilateur**.
- `solutions/` — corrigés (après tentative !).
- `PROGRESS.md` — suivi.
- `CONVERSATION.md` — historique de la conversation qui a produit ce parcours (contexte pour Claude Code).

## Aucune dépendance
Tout fonctionne avec la bibliothèque standard, hors-ligne.
L'async (tokio), serde, thiserror, etc. sont présentés dans les leçons et réservés aux extensions.
