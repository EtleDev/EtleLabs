//! Module 5 — Option, Result et gestion d'erreurs (pas d'exceptions !)
//! Lancer : cargo test m05

use std::fmt;
use std::num::ParseIntError;

// ---------------------------------------------------------------------------
// Une erreur de domaine « maison »
// ---------------------------------------------------------------------------

#[derive(Debug, PartialEq)]
pub enum AgeError {
    NotANumber,
    OutOfRange(i64),
}

/// `Display` = le « ToString() » destiné aux humains (messages d'erreur).
impl fmt::Display for AgeError {
    fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
        match self {
            AgeError::NotANumber => write!(f, "l'âge n'est pas un nombre"),
            AgeError::OutOfRange(n) => write!(f, "l'âge {} est hors limites (0-150)", n),
        }
    }
}

impl std::error::Error for AgeError {}

/// Parse un âge entre 0 et 150 (espaces ignorés).
/// "abc" → Err(NotANumber) ; "200" → Err(OutOfRange(200)) ; "42" → Ok(42).
/// Indices : `parse::<i64>()`, `map_err(|_| …)`, l'opérateur `?`, `(0..=150).contains(&n)`.
pub fn parse_age(s: &str) -> Result<u8, AgeError> {
    let n = s
        .trim()
        .parse::<i64>()
        .map_err(|_| AgeError::NotANumber)?;
    if (0..=150).contains(&n) {
        Ok(n as u8)
    } else {
        Err(AgeError::OutOfRange(n))
    }
}

// ---------------------------------------------------------------------------
// Conversion automatique d'erreurs avec From + `?`
// ---------------------------------------------------------------------------

#[derive(Debug, PartialEq)]
pub enum ConfigError {
    Missing(String),
    InvalidNumber(ParseIntError),
}

/// C'est ce `From` qui permet à `?` de convertir ParseIntError → ConfigError automatiquement.
impl From<ParseIntError> for ConfigError {
    fn from(e: ParseIntError) -> Self {
        ConfigError::InvalidNumber(e)
    }
}

/// Lit un port depuis une valeur optionnelle (ex. variable d'environnement).
/// None → Err(Missing("PORT")) ; texte invalide → Err(InvalidNumber(..)) ; sinon Ok(port).
/// Indices : `ok_or_else(|| …)?` pour Option → Result, puis `parse::<u16>()?`.
pub fn parse_port(raw: Option<&str>) -> Result<u16, ConfigError> {
    let raw = raw.ok_or_else(|| ConfigError::Missing("PORT".to_string()))?;
    let port = raw.trim().parse::<u16>()?;
    Ok(port)
}

/// Additionne des entiers écrits en texte. Échoue à la PREMIÈRE entrée invalide (court-circuit).
pub fn sum_ints(inputs: &[&str]) -> Result<i32, ParseIntError> {
    let mut total = 0;
    for s in inputs {
        total += s.trim().parse::<i32>()?;
    }
    Ok(total)
}

// ---------------------------------------------------------------------------
// Combinateurs d'Option : map / filter / and_then / ok / unwrap_or
// ---------------------------------------------------------------------------

/// Parse un entier STRICTEMENT positif tenant dans un u32. Sinon None.
/// Contrainte : une seule chaîne d'appels, sans `match` ni `if`.
/// Indice : parse::<i64>() → .ok() → .filter(..) → .and_then(|n| u32::try_from(n).ok())
pub fn parse_positive(s: &str) -> Option<u32> {
    s.trim()
        .parse::<i64>()
        .ok()
        .filter(|n| *n > 0)
        .and_then(|n| u32::try_from(n).ok())
}

/// Longueur du deuxième prénom, 0 s'il n'y en a pas. (`map` + `unwrap_or`)
pub fn middle_name_len(middle: Option<&str>) -> usize {
    middle.map(|m| m.len()).unwrap_or(0)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn age_ok_and_errors() {
        assert_eq!(parse_age("42"), Ok(42));
        assert_eq!(parse_age(" 0 "), Ok(0));
        assert_eq!(parse_age("abc"), Err(AgeError::NotANumber));
        assert_eq!(parse_age("200"), Err(AgeError::OutOfRange(200)));
        assert_eq!(parse_age("-1"), Err(AgeError::OutOfRange(-1)));
    }

    #[test]
    fn age_error_display() {
        assert!(AgeError::OutOfRange(200).to_string().contains("200"));
        assert!(!AgeError::NotANumber.to_string().is_empty());
    }

    #[test]
    fn port_parsing() {
        assert_eq!(parse_port(Some("8080")), Ok(8080));
        assert_eq!(parse_port(None), Err(ConfigError::Missing("PORT".to_string())));
        assert!(matches!(parse_port(Some("abc")), Err(ConfigError::InvalidNumber(_))));
        assert!(matches!(parse_port(Some("70000")), Err(ConfigError::InvalidNumber(_))));
    }

    #[test]
    fn sum_ints_works() {
        assert_eq!(sum_ints(&["1", " 2", "3 "]), Ok(6));
        assert!(sum_ints(&["1", "x", "3"]).is_err());
        assert_eq!(sum_ints(&[]), Ok(0));
    }

    #[test]
    fn positive() {
        assert_eq!(parse_positive("42"), Some(42));
        assert_eq!(parse_positive(" 7 "), Some(7));
        assert_eq!(parse_positive("0"), None);
        assert_eq!(parse_positive("-5"), None);
        assert_eq!(parse_positive("abc"), None);
        assert_eq!(parse_positive("99999999999"), None);
    }

    #[test]
    fn middle() {
        assert_eq!(middle_name_len(Some("Augusta")), 7);
        assert_eq!(middle_name_len(None), 0);
    }
}
