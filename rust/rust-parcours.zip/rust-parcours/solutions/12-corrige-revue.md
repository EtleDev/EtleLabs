# Corrigé — Revue de code (module 12)

### Extrait 1
- `&Vec<String>` → `&[String]` (voire `&[&str]`/`impl IntoIterator`).
- `prices.clone()` : clone **inutile** du Vec entier (et de chaque String). Itérer sur `prices` (emprunt).
- `.unwrap()` sur une entrée externe : **panic** si une chaîne n'est pas un nombre.
- `u32` : l'addition peut **déborder** (panic en debug, wrap silencieux en release).
- Retour sans erreur possible : la fonction ne peut pas dire « entrée invalide ».
```rust
pub fn total(prices: &[String]) -> Result<u32, TotalError> {
    prices.iter().try_fold(0u32, |acc, p| {
        let n = p.trim().parse::<u32>().map_err(TotalError::Parse)?;
        acc.checked_add(n).ok_or(TotalError::Overflow)
    })
}
```

### Extrait 2
- Lifetimes dans un **modèle de domaine** : l'ordre ne peut pas être stocké, renvoyé ni envoyé dans un thread sans traîner la source des `&str`. Un agrégat **possède** ses données (`String`, ou mieux des newtypes `OrderId`, `CustomerId`).
- `status: String` : chaînes magiques, états invalides représentables ("peding").
- `tracking: Option<String>` indépendant du statut : `status == "pending"` avec un `tracking` Some = état illégal.
- Tous les champs `pub` : plus d'invariants.
- `f64` pour de l'argent : erreurs d'arrondi. Utiliser des entiers en centimes / un newtype `Money`.
```rust
pub enum OrderState { Pending, Paid, Shipped { tracking: TrackingNumber } }
pub struct Order { id: OrderId, customer: CustomerId, state: OrderState, total: Money }
```

### Extrait 3
- Design **OO porté tel quel** : références circulaires `Order ⇄ Customer` avec `Rc` → **fuite mémoire** (cycle jamais libéré, il faudrait `Weak`).
- `RefCell` partout : les violations d'emprunt deviennent des **panics à l'exécution** (`already borrowed`).
- Pas thread-safe (`Rc`), donc inutilisable dans un serveur async multi-thread.
- Alternative idiomatique/DDD : agrégats **séparés**, références par **identifiant** (`CustomerId` dans `Order`), repositories pour résoudre les liens.

### Extrait 4
- `Result<_, String>` : erreurs **non typées** → impossible de `match` sur la cause (fichier absent vs JSON invalide).
- `.map_err(|e| e.to_string())` : perd la chaîne de causes (`source()`).
- `let _ = validate(&cfg);` : le résultat de validation est **ignoré** → configuration invalide acceptée. Gros bug silencieux.
```rust
#[derive(thiserror::Error, Debug)]
pub enum ConfigError {
    #[error("lecture impossible : {0}")] Io(#[from] std::io::Error),
    #[error("JSON invalide : {0}")]      Json(#[from] serde_json::Error),
    #[error("configuration invalide : {0}")] Invalid(String),
}
fn load(path: &str) -> Result<Config, ConfigError> {
    let cfg: Config = serde_json::from_str(&std::fs::read_to_string(path)?)?;
    validate(&cfg)?;
    Ok(cfg)
}
```

### Extrait 5
- `std::sync::MutexGuard` **tenu à travers un `.await`** : le future n'est pas `Send` (erreur de compilation dans un runtime multi-thread) ou, avec un autre mutex, risque de **deadlock** et de contention énorme (tout le monde attend le réseau).
- `.lock().unwrap()` : panic si poisoning.
- Un unique `Arc<Mutex<AppState>>` global = goulot d'étranglement.
```rust
let user = db.fetch_user(req.user_id).await;          // d'abord l'I/O, sans verrou
state.lock().unwrap().last_seen.insert(req.user_id, now()); // verrou court, sans await
```
Mieux : `DashMap`, `RwLock`, ou un acteur/canal pour `last_seen`.

### Extrait 6
- `Box<dyn Trait>` pour un ensemble **fermé et connu** : allocation + vtable inutiles, et le `Box` prend la propriété pour un simple calcul.
- Alternatives : un **enum** `Shipping { Standard, Express }` avec `match` (exhaustif, zéro allocation), ou un générique `fn price(s: &impl ShippingStrategy, …)`.
- Sur-abstraction de type « Strategy » du C#/Java.

### Extrait 7
- `(age / 10) as u8` : `as` **tronque silencieusement** (ex. 3000 ans → 44) et un âge négatif donne une valeur absurde. Utiliser `u8::try_from(..)` et valider l'entrée.
- `&name[0..1]` : panic si `name` est vide ou si le 1er caractère fait plus d'un octet (UTF-8, ex. « É »). Panic aussi pour `name.len() - 1` sur chaîne vide (underflow).
```rust
fn initials(name: &str) -> String {
    let mut chars = name.chars();
    match (chars.next(), chars.last()) {
        (Some(a), Some(b)) => format!("{a}{b}"),
        (Some(a), None) => a.to_string(),
        _ => String::new(),
    }
}
```

### Extrait 8
- `unsafe` **sans contrôle de borne** : lecture hors limites = comportement **indéfini** (corruption mémoire, faille de sécurité). Aucun commentaire `// SAFETY:`.
- `&Vec<i32>` → `&[i32]`.
- Aucun gain de perf démontré : `v[i]` ou `v.get(i)` suffit, et l'optimiseur supprime souvent les vérifications dans les boucles. Un `unsafe` doit être **mesuré** et **justifié**.
```rust
fn get(v: &[i32], i: usize) -> Option<i32> { v.get(i).copied() }
```
