//! Module 4 — Structs, enums (types algébriques) et pattern matching
//! Lancer : cargo test m04

use std::f64::consts::PI;

// ---------------------------------------------------------------------------
// Value Object : Money (encapsulation + invariants, comme un `record` C#)
// ---------------------------------------------------------------------------

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Currency {
    Eur,
    Usd,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct Money {
    cents: i64,
    currency: Currency,
}

impl Money {
    pub fn new(cents: i64, currency: Currency) -> Self {
        Money { cents, currency }
    }

    pub fn cents(&self) -> i64 {
        self.cents
    }

    pub fn currency(&self) -> Currency {
        self.currency
    }

    /// Additionne deux montants. `None` si les devises diffèrent ou en cas de dépassement.
    pub fn checked_add(&self, other: &Money) -> Option<Money> {
        if self.currency != other.currency {
            return None;
        }
        self.cents
            .checked_add(other.cents)
            .map(|c| Money::new(c, self.currency))
    }

    /// Format "12.34 EUR", "0.05 USD", "-2.50 EUR".
    pub fn display(&self) -> String {
        let code = match self.currency {
            Currency::Eur => "EUR",
            Currency::Usd => "USD",
        };
        let sign = if self.cents < 0 { "-" } else { "" };
        let abs = self.cents.abs();
        format!("{}{}.{:02} {}", sign, abs / 100, abs % 100, code)
    }
}

// ---------------------------------------------------------------------------
// Enum avec données : chaque variante porte des champs différents
// ---------------------------------------------------------------------------

#[derive(Debug, Clone, PartialEq)]
pub enum Shape {
    Circle { radius: f64 },
    Rectangle { width: f64, height: f64 },
    Triangle { base: f64, height: f64 },
}

/// Aire d'une forme. `match` est EXHAUSTIF : si on ajoute une variante, le compilateur
/// signale tous les `match` à compléter (pas de `default` silencieux comme un `switch` C#).
pub fn area(shape: &Shape) -> f64 {
    match shape {
        Shape::Circle { radius } => PI * radius * radius,
        Shape::Rectangle { width, height } => width * height,
        Shape::Triangle { base, height } => base * height / 2.0,
    }
}

// ---------------------------------------------------------------------------
// Machine à états : rendre les états invalides IMPOSSIBLES À REPRÉSENTER
// ---------------------------------------------------------------------------

#[derive(Debug, Clone, PartialEq)]
pub enum OrderState {
    Draft,
    Placed { items: u32 },
    Shipped { tracking: String },
    Cancelled,
}

pub fn describe(state: &OrderState) -> String {
    match state {
        OrderState::Draft => "brouillon".to_string(),
        OrderState::Placed { items } => format!("commandée ({} articles)", items),
        OrderState::Shipped { tracking } => format!("expédiée ({})", tracking),
        OrderState::Cancelled => "annulée".to_string(),
    }
}

/// Seule une commande `Placed` peut être expédiée ; tout autre état est renvoyé inchangé.
pub fn ship(state: OrderState, tracking: &str) -> OrderState {
    match state {
        OrderState::Placed { .. } => OrderState::Shipped {
            tracking: tracking.to_string(),
        },
        other => other,
    }
}

/// On peut annuler un brouillon ou une commande passée, pas une commande expédiée/annulée.
/// Indice : la macro `matches!(valeur, motif1 | motif2)`.
pub fn can_cancel(state: &OrderState) -> bool {
    matches!(state, OrderState::Draft | OrderState::Placed { .. })
}

// ---------------------------------------------------------------------------
// Patterns : intervalles, alternatives, Option
// ---------------------------------------------------------------------------

/// 200..=299 → "success", 300..=399 → "redirection", 400..=499 → "client error",
/// 500..=599 → "server error", sinon "unknown".
pub fn classify_http(code: u16) -> &'static str {
    match code {
        200..=299 => "success",
        300..=399 => "redirection",
        400..=499 => "client error",
        500..=599 => "server error",
        _ => "unknown",
    }
}

/// "Ada Lovelace" ou, avec un deuxième prénom, "Ada Augusta Lovelace".
pub fn full_name(first: &str, middle: Option<&str>, last: &str) -> String {
    match middle {
        Some(m) => format!("{} {} {}", first, m, last),
        None => format!("{} {}", first, last),
    }
}

// ---------------------------------------------------------------------------
// Newtype validé : « parse, don't validate »
// ---------------------------------------------------------------------------

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Email(String);

impl Email {
    /// Un email valide : une partie locale non vide, un seul '@', un domaine contenant un '.'.
    /// On normalise en minuscules. Retourne None sinon.
    /// Indice : `s.trim().split_once('@')` renvoie `Option<(&str, &str)>` ; garde de match : `Some((l, d)) if …`.
    pub fn parse(s: &str) -> Option<Email> {
        match s.trim().split_once('@') {
            Some((local, domain))
                if !local.is_empty() && domain.contains('.') && !domain.contains('@') =>
            {
                Some(Email(format!("{}@{}", local, domain).to_lowercase()))
            }
            _ => None,
        }
    }

    pub fn as_str(&self) -> &str {
        &self.0
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn money_basics() {
        let a = Money::new(1050, Currency::Eur);
        let b = Money::new(250, Currency::Eur);
        let sum = a.checked_add(&b).unwrap();
        assert_eq!(sum.cents(), 1300);
        assert_eq!(sum.currency(), Currency::Eur);
    }

    #[test]
    fn money_rejects_mixed_currencies_and_overflow() {
        let eur = Money::new(100, Currency::Eur);
        let usd = Money::new(100, Currency::Usd);
        assert_eq!(eur.checked_add(&usd), None);
        let max = Money::new(i64::MAX, Currency::Eur);
        assert_eq!(max.checked_add(&eur), None);
    }

    #[test]
    fn money_display() {
        assert_eq!(Money::new(1234, Currency::Eur).display(), "12.34 EUR");
        assert_eq!(Money::new(5, Currency::Usd).display(), "0.05 USD");
        assert_eq!(Money::new(-250, Currency::Eur).display(), "-2.50 EUR");
    }

    #[test]
    fn areas() {
        let close = |a: f64, b: f64| (a - b).abs() < 1e-9;
        assert!(close(area(&Shape::Circle { radius: 1.0 }), PI));
        assert!(close(area(&Shape::Rectangle { width: 2.0, height: 3.0 }), 6.0));
        assert!(close(area(&Shape::Triangle { base: 4.0, height: 3.0 }), 6.0));
    }

    #[test]
    fn order_state_machine() {
        assert_eq!(describe(&OrderState::Draft), "brouillon");
        assert_eq!(describe(&OrderState::Placed { items: 3 }), "commandée (3 articles)");

        let shipped = ship(OrderState::Placed { items: 1 }, "TRK-1");
        assert_eq!(shipped, OrderState::Shipped { tracking: "TRK-1".to_string() });
        assert_eq!(describe(&shipped), "expédiée (TRK-1)");

        // Un brouillon ne peut pas être expédié : état inchangé
        assert_eq!(ship(OrderState::Draft, "X"), OrderState::Draft);
        assert_eq!(ship(OrderState::Cancelled, "X"), OrderState::Cancelled);
    }

    #[test]
    fn cancel_rules() {
        assert!(can_cancel(&OrderState::Draft));
        assert!(can_cancel(&OrderState::Placed { items: 2 }));
        assert!(!can_cancel(&OrderState::Shipped { tracking: "T".to_string() }));
        assert!(!can_cancel(&OrderState::Cancelled));
    }

    #[test]
    fn http() {
        assert_eq!(classify_http(200), "success");
        assert_eq!(classify_http(301), "redirection");
        assert_eq!(classify_http(404), "client error");
        assert_eq!(classify_http(503), "server error");
        assert_eq!(classify_http(100), "unknown");
    }

    #[test]
    fn names() {
        assert_eq!(full_name("Ada", None, "Lovelace"), "Ada Lovelace");
        assert_eq!(full_name("Ada", Some("Augusta"), "Lovelace"), "Ada Augusta Lovelace");
    }

    #[test]
    fn email_parsing() {
        assert_eq!(Email::parse(" Ada@Example.COM ").unwrap().as_str(), "ada@example.com");
        assert_eq!(Email::parse("@x.com"), None);
        assert_eq!(Email::parse("ada@"), None);
        assert_eq!(Email::parse("ada@localhost"), None);
        assert_eq!(Email::parse("ada@@x.com"), None);
        assert_eq!(Email::parse("sans-arobase"), None);
    }
}
