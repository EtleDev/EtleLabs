// On ne peut pas renvoyer une référence vers une variable locale (elle est détruite en sortie de fonction).
// On renvoie la valeur POSSÉDÉE : la propriété est transférée à l'appelant.
fn make_greeting() -> String {
    let s = String::from("Bonjour");
    s
}

fn main() {
    println!("{}", make_greeting());
}

// Autre option si le texte est constant : `fn make_greeting() -> &'static str { "Bonjour" }`
