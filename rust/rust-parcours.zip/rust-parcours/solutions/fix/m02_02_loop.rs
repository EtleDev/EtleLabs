// `for n in names` appelle into_iter() qui CONSOMME le Vec. On itère sur une référence.
fn main() {
    let names = vec![String::from("Ada"), String::from("Grace")];

    for n in &names {
        println!("{}", n);
    }

    println!("{} noms traités", names.len());
}
