// `Rc` utilise un compteur NON atomique : le partager entre threads créerait une data race.
// `Arc` (Atomic Reference Counted) est la version thread-safe.
use std::sync::Arc;
use std::thread;

fn main() {
    let data = Arc::new(vec![1, 2, 3]);
    let d = Arc::clone(&data);

    let handle = thread::spawn(move || {
        println!("dans le thread : {:?}", d);
    });

    handle.join().unwrap();
    println!("dans main : {:?}", data);
}
