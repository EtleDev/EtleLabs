// Correction A : consommer l'emprunt AVANT la mutation (l'emprunt se termine à sa dernière utilisation).
fn main() {
    let mut scores = vec![10, 20, 30];

    let first = &scores[0];
    println!("premier = {}", first);
    scores.push(40);
}

// Correction B : copier la valeur (i32 est Copy) — plus aucun emprunt vivant :
//     let first = scores[0];
//     scores.push(40);
//     println!("premier = {}", first);
