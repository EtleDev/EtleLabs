// Le paramètre passe de `String` (prise de possession) à `&str` (simple emprunt en lecture).
fn print_len(s: &str) {
    println!("longueur = {}", s.len());
}

fn main() {
    let name = String::from("Rust");
    print_len(&name); // &String se convertit automatiquement en &str
    println!("{} est toujours utilisable", name);
}
