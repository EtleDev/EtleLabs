//! Module 8 — Collections et pointeurs intelligents (Box, Rc, RefCell)
//! Lancer : cargo test m08

use std::cell::RefCell;
use std::collections::{BTreeMap, BTreeSet, HashMap};
use std::rc::Rc;

/// Fréquence de chaque mot (en minuscules, séparés par des espaces).
/// Indice : `*map.entry(clé).or_insert(0) += 1;`  — l'API Entry évite le double lookup.
pub fn word_frequencies(text: &str) -> HashMap<String, usize> {
    let mut map = HashMap::new();
    for w in text.split_whitespace() {
        *map.entry(w.to_lowercase()).or_insert(0) += 1;
    }
    map
}

/// Regroupe les mots par première lettre (en minuscule). Les mots vides sont ignorés.
/// BTreeMap = clés triées (ordre déterministe, pratique en test).
/// Indice : `entry(c).or_default().push(…)`.
pub fn group_by_first_letter(words: &[&str]) -> BTreeMap<char, Vec<String>> {
    let mut map: BTreeMap<char, Vec<String>> = BTreeMap::new();
    for w in words {
        if let Some(c) = w.chars().next() {
            map.entry(c.to_ascii_lowercase()).or_default().push(w.to_string());
        }
    }
    map
}

/// Supprime les doublons ET trie. Indice : passer par un BTreeSet.
pub fn dedup_sorted(v: Vec<i32>) -> Vec<i32> {
    let set: BTreeSet<i32> = v.into_iter().collect();
    set.into_iter().collect()
}

// ---------------------------------------------------------------------------
// Box<T> : allocation sur le tas, indispensable pour les types récursifs
// ---------------------------------------------------------------------------

/// Arbre binaire de recherche. Sans `Box`, `Tree` aurait une taille infinie → ne compile pas.
#[derive(Debug, Clone, PartialEq)]
pub enum Tree {
    Leaf,
    Node(Box<Tree>, i32, Box<Tree>),
}

impl Tree {
    /// Insère `v` (les doublons sont ignorés). Prend `self` par valeur et renvoie le nouvel arbre :
    /// style « persistant », sans mutation.
    pub fn insert(self, v: i32) -> Tree {
        match self {
            Tree::Leaf => Tree::Node(Box::new(Tree::Leaf), v, Box::new(Tree::Leaf)),
            Tree::Node(l, x, r) => {
                if v < x {
                    Tree::Node(Box::new((*l).insert(v)), x, r)
                } else if v > x {
                    Tree::Node(l, x, Box::new((*r).insert(v)))
                } else {
                    Tree::Node(l, x, r)
                }
            }
        }
    }

    pub fn contains(&self, v: i32) -> bool {
        match self {
            Tree::Leaf => false,
            Tree::Node(l, x, r) => {
                if v == *x {
                    true
                } else if v < *x {
                    l.contains(v)
                } else {
                    r.contains(v)
                }
            }
        }
    }

    /// Valeurs triées (parcours infixe : gauche, nœud, droite).
    pub fn in_order(&self) -> Vec<i32> {
        match self {
            Tree::Leaf => Vec::new(),
            Tree::Node(l, x, r) => {
                let mut out = l.in_order();
                out.push(*x);
                out.extend(r.in_order());
                out
            }
        }
    }
}

// ---------------------------------------------------------------------------
// Rc<RefCell<T>> : propriété PARTAGÉE + mutabilité intérieure (monothread)
// À utiliser avec parcimonie : c'est souvent le signe d'un design porté depuis l'OO.
// ---------------------------------------------------------------------------

/// Renvoie un « logger » qui ajoute "[prefix] message" dans un journal PARTAGÉ.
/// Plusieurs loggers écrivent dans le même `Vec`.
/// Indices : copie `prefix` en String ; `move |msg| log.borrow_mut().push(format!(…))`.
pub fn make_logger(log: Rc<RefCell<Vec<String>>>, prefix: &str) -> impl Fn(&str) {
    let prefix = prefix.to_string();
    move |msg| log.borrow_mut().push(format!("[{}] {}", prefix, msg))
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn frequencies() {
        let f = word_frequencies("Le chat et le chien et LE rat");
        assert_eq!(f["le"], 3);
        assert_eq!(f["et"], 2);
        assert_eq!(f["chat"], 1);
        assert_eq!(f.len(), 5);
    }

    #[test]
    fn grouping() {
        let g = group_by_first_letter(&["apple", "avocado", "banana", "Blueberry", "cherry", ""]);
        assert_eq!(g[&'a'], vec!["apple".to_string(), "avocado".to_string()]);
        assert_eq!(g[&'b'], vec!["banana".to_string(), "Blueberry".to_string()]);
        assert_eq!(g[&'c'], vec!["cherry".to_string()]);
        assert_eq!(g.len(), 3);
    }

    #[test]
    fn dedup() {
        assert_eq!(dedup_sorted(vec![3, 1, 3, 2, 1]), vec![1, 2, 3]);
        assert_eq!(dedup_sorted(vec![]), Vec::<i32>::new());
    }

    #[test]
    fn tree() {
        let t = [5, 3, 8, 1, 4, 5, 9]
            .iter()
            .fold(Tree::Leaf, |t, v| t.insert(*v));
        assert_eq!(t.in_order(), vec![1, 3, 4, 5, 8, 9]);
        assert!(t.contains(4));
        assert!(t.contains(9));
        assert!(!t.contains(7));
        assert!(!Tree::Leaf.contains(1));
    }

    #[test]
    fn shared_logger() {
        let log = Rc::new(RefCell::new(Vec::new()));
        let a = make_logger(Rc::clone(&log), "A");
        let b = make_logger(Rc::clone(&log), "B");
        a("hello");
        b("world");
        a("again");
        assert_eq!(
            *log.borrow(),
            vec!["[A] hello".to_string(), "[B] world".to_string(), "[A] again".to_string()]
        );
        // `log` + les deux clones capturés dans les closures
        assert_eq!(Rc::strong_count(&log), 3);
    }
}
