//! Module 7 — Closures et itérateurs (le LINQ de Rust)
//! Lancer : cargo test m07
//!
//! Les itérateurs sont PARESSEUX : rien ne s'exécute tant qu'on n'appelle pas
//! un « consommateur » (collect, sum, count, for, last, …). Comme LINQ avec ses IEnumerable.

use std::num::ParseIntError;

/// Renvoie une closure qui ajoute `n` à son argument.
/// `move` : la closure PREND POSSESSION de `n` (sinon elle l'emprunterait, et `n` mourrait à la sortie de la fonction).
pub fn make_adder(n: i32) -> impl Fn(i32) -> i32 {
    move |x| x + n
}

/// Applique `f` deux fois : f(f(x)). `F: Fn(i32) -> i32` est une contrainte de trait (≈ Func<int,int>).
pub fn apply_twice<F: Fn(i32) -> i32>(f: F, x: i32) -> i32 {
    f(f(x))
}

/// Renvoie une closure à ÉTAT : chaque appel renvoie 1, puis 2, puis 3…
/// Elle MUTE sa variable capturée → c'est un `FnMut` (et non un `Fn`).
pub fn make_counter() -> impl FnMut() -> u32 {
    let mut c = 0;
    move || {
        c += 1;
        c
    }
}

/// Somme des carrés des nombres IMPAIRS. Une seule chaîne : iter → filter → map → sum.
/// (LINQ : v.Where(x => x % 2 != 0).Select(x => x * x).Sum())
pub fn sum_of_squares_of_odds(v: &[i32]) -> i32 {
    v.iter().filter(|x| **x % 2 != 0).map(|x| x * x).sum()
}

/// Longueur de chaque mot. (`split_whitespace`, `map`, `collect`)
pub fn word_lengths(text: &str) -> Vec<usize> {
    text.split_whitespace().map(|w| w.len()).collect()
}

/// Les `n` plus grandes valeurs, par ordre décroissant.
/// Indice : copie en Vec (`to_vec`), `sort_by(|a, b| b.cmp(a))`, `truncate(n)`.
pub fn top_n(v: &[i32], n: usize) -> Vec<i32> {
    let mut c = v.to_vec();
    c.sort_by(|a, b| b.cmp(a));
    c.truncate(n);
    c
}

/// Indice du premier élément négatif. Indice : `position`.
pub fn find_first_negative(v: &[i32]) -> Option<usize> {
    v.iter().position(|x| *x < 0)
}

/// Parse tout ou rien : un seul Err fait échouer l'ensemble.
/// Astuce : `collect()` sait produire un `Result<Vec<_>, _>` à partir d'un itérateur de `Result`.
pub fn parse_all(inputs: &[&str]) -> Result<Vec<i32>, ParseIntError> {
    inputs.iter().map(|s| s.trim().parse::<i32>()).collect()
}

/// Nombre de fois où la valeur augmente par rapport à la précédente. Indice : `windows(2)`.
pub fn count_increases(v: &[i32]) -> usize {
    v.windows(2).filter(|w| w[1] > w[0]).count()
}

/// Un itérateur personnalisé : 0, 1, 1, 2, 3, 5, 8…
/// Implémenter `Iterator` (une seule méthode : `next`) donne GRATUITEMENT map, filter, take, zip, sum…
pub struct Fib {
    a: u64,
    b: u64,
}

impl Fib {
    pub fn new() -> Self {
        Fib { a: 0, b: 1 }
    }
}

impl Iterator for Fib {
    type Item = u64;

    fn next(&mut self) -> Option<u64> {
        let current = self.a;
        self.a = self.b;
        self.b = current + self.b;
        Some(current)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn adder() {
        let add5 = make_adder(5);
        assert_eq!(add5(1), 6);
        assert_eq!(add5(10), 15);
    }

    #[test]
    fn twice() {
        assert_eq!(apply_twice(|x| x * 3, 2), 18);
        assert_eq!(apply_twice(make_adder(10), 0), 20);
    }

    #[test]
    fn counter() {
        let mut c = make_counter();
        assert_eq!(c(), 1);
        assert_eq!(c(), 2);
        let mut other = make_counter();
        assert_eq!(other(), 1); // état indépendant
        assert_eq!(c(), 3);
    }

    #[test]
    fn squares_of_odds() {
        assert_eq!(sum_of_squares_of_odds(&[1, 2, 3, 4, 5]), 35);
        assert_eq!(sum_of_squares_of_odds(&[]), 0);
    }

    #[test]
    fn lengths() {
        assert_eq!(word_lengths("un deux  trois"), vec![2, 4, 5]);
    }

    #[test]
    fn top() {
        assert_eq!(top_n(&[5, 1, 9, 3, 7], 3), vec![9, 7, 5]);
        assert_eq!(top_n(&[1, 2], 5), vec![2, 1]);
    }

    #[test]
    fn first_negative() {
        assert_eq!(find_first_negative(&[3, 4, -1, -2]), Some(2));
        assert_eq!(find_first_negative(&[1, 2]), None);
    }

    #[test]
    fn parse_all_works() {
        assert_eq!(parse_all(&["1", " 2 ", "3"]), Ok(vec![1, 2, 3]));
        assert!(parse_all(&["1", "oops"]).is_err());
    }

    #[test]
    fn increases() {
        assert_eq!(count_increases(&[199, 200, 208, 210, 200, 207, 240, 269, 260, 263]), 7);
        assert_eq!(count_increases(&[1]), 0);
    }

    #[test]
    fn fibonacci() {
        let first: Vec<u64> = Fib::new().take(8).collect();
        assert_eq!(first, vec![0, 1, 1, 2, 3, 5, 8, 13]);
        let even_sum: u64 = Fib::new().take_while(|x| *x < 100).filter(|x| x % 2 == 0).sum();
        assert_eq!(even_sum, 0 + 2 + 8 + 34);
    }
}
