//! Module 1 — Les bases
//! Lancer : cargo test m01

/// Retourne le double de `x`.
/// Rappel : pas de `return` nécessaire, la dernière expression (sans `;`) est la valeur retournée.
pub fn double(x: i32) -> i32 {
    x * 2
}

/// Convertit des degrés Celsius en Fahrenheit : F = C × 9/5 + 32
pub fn celsius_to_fahrenheit(c: f64) -> f64 {
    c * 9.0 / 5.0 + 32.0
}

/// Classe un entier : "negatif", "zero" ou "positif".
/// Contrainte : utilise `if` comme EXPRESSION (pas de `return`, pas de variable intermédiaire).
pub fn classify(n: i32) -> &'static str {
    if n < 0 {
        "negatif"
    } else if n == 0 {
        "zero"
    } else {
        "positif"
    }
}

/// FizzBuzz : "Fizz" si multiple de 3, "Buzz" si multiple de 5,
/// "FizzBuzz" si les deux, sinon le nombre en texte.
/// Indice : `match` sur un tuple `(n % 3, n % 5)`.
pub fn fizzbuzz(n: u32) -> String {
    match (n % 3, n % 5) {
        (0, 0) => "FizzBuzz".to_string(),
        (0, _) => "Fizz".to_string(),
        (_, 0) => "Buzz".to_string(),
        _ => n.to_string(),
    }
}

/// Somme des nombres pairs de 1 à n inclus.
/// Indice : variable `mut`, boucle `for`, range `1..=n`.
pub fn sum_even_up_to(n: u32) -> u32 {
    let mut total = 0;
    for i in 1..=n {
        if i % 2 == 0 {
            total += i;
        }
    }
    total
}

/// Renvoie (min, max) d'un tableau de 5 entiers (un tuple).
pub fn min_max(values: [i32; 5]) -> (i32, i32) {
    let mut min = values[0];
    let mut max = values[0];
    for v in values {
        if v < min {
            min = v;
        }
        if v > max {
            max = v;
        }
    }
    (min, max)
}

/// Addition de deux u8 SANS dépassement silencieux : `None` si ça déborde.
/// (C# : `checked` vs `unchecked`. Rust : en debug = panic, en release = wrap-around !
///  Soyez explicite avec checked_*, wrapping_*, saturating_*.)
pub fn checked_add_u8(a: u8, b: u8) -> Option<u8> {
    a.checked_add(b)
}

/// Parse un entier depuis du texte (espaces ignorés). Si invalide → 0.
/// Montre le *shadowing* : `let s = s.trim();` redéclare `s`, c'est idiomatique.
pub fn parse_or_zero(s: &str) -> i32 {
    let s = s.trim();
    s.parse::<i32>().unwrap_or(0)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn double_works() {
        assert_eq!(double(21), 42);
        assert_eq!(double(-3), -6);
    }

    #[test]
    fn temperature() {
        assert!((celsius_to_fahrenheit(100.0) - 212.0).abs() < 1e-9);
        assert!((celsius_to_fahrenheit(0.0) - 32.0).abs() < 1e-9);
    }

    #[test]
    fn classify_works() {
        assert_eq!(classify(-5), "negatif");
        assert_eq!(classify(0), "zero");
        assert_eq!(classify(7), "positif");
    }

    #[test]
    fn fizzbuzz_works() {
        assert_eq!(fizzbuzz(3), "Fizz");
        assert_eq!(fizzbuzz(10), "Buzz");
        assert_eq!(fizzbuzz(15), "FizzBuzz");
        assert_eq!(fizzbuzz(7), "7");
    }

    #[test]
    fn sum_even() {
        assert_eq!(sum_even_up_to(10), 30);
        assert_eq!(sum_even_up_to(0), 0);
    }

    #[test]
    fn min_max_works() {
        assert_eq!(min_max([3, -1, 9, 4, 0]), (-1, 9));
        assert_eq!(min_max([5, 5, 5, 5, 5]), (5, 5));
    }

    #[test]
    fn checked_add() {
        assert_eq!(checked_add_u8(100, 100), Some(200));
        assert_eq!(checked_add_u8(200, 100), None);
    }

    #[test]
    fn parse_or_zero_works() {
        assert_eq!(parse_or_zero(" 42 "), 42);
        assert_eq!(parse_or_zero("abc"), 0);
        assert_eq!(parse_or_zero(""), 0);
    }
}
